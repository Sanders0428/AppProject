import { getAuth } from 'firebase/auth';
import api from './api';

export type BackendUser = {
  id: string;
  fullName?: string;
  email?: string;
  role?: 'learner' | 'admin' | string;
  // any other backend fields
};

export async function verifyWithBackend(): Promise<BackendUser | null> {
  try {
    const res = await api.post('/auth/verify'); // backend verifies Firebase token from Authorization header
    return res.data as BackendUser;
  } catch (err: any) {
    // If backend returns 401/400 try forcing token refresh once then retry
    const auth = getAuth();
    if (auth.currentUser) {
      try {
        await auth.currentUser.getIdToken(true); // force refresh
        const retry = await api.post('/auth/verify');
        return retry.data as BackendUser;
      } catch (retryErr) {
        return null;
      }
    }
    return null;
  }
}
