// src/lib/api.ts
import axios from 'axios';
import { getAuth } from 'firebase/auth';

const API_BASE = 'https://your-app.elasticbeanstalk.com/api'; // <- replace with your backend base URL

const api = axios.create({
  baseURL: API_BASE,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach Firebase ID token to requests
api.interceptors.request.use(
  async (config) => {
    try {
      const auth = getAuth();
      const user = auth.currentUser;
      if (user && config.headers) {
        const idToken = await user.getIdToken(false);
        if (idToken) config.headers.Authorization = `Bearer ${idToken}`;
      }
    } catch (err) {
      // token attach failed — continue without Authorization header
      // console.warn('Failed to attach idToken', err);
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export default api;
