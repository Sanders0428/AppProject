// src/components/BottomNavigation.tsx
import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';

type TabName = 'dashboard' | 'courses' | 'calendar' | 'profile';
type TabIcon = 'home' | 'book' | 'calendar' | 'user';

type Props = {
  userRole?: 'learner' | 'admin';
  activeTab: TabName;
};

const tabs: { name: TabName; label: string; icon: TabIcon; route: string }[] = [
  { name: 'dashboard', label: 'Home', icon: 'home', route: '/dashboard' },
  { name: 'courses', label: 'Courses', icon: 'book', route: '/courses' },
  { name: 'calendar', label: 'Calendar', icon: 'calendar', route: '/calendar' },
  { name: 'profile', label: 'Profile', icon: 'user', route: '/profile' },
];

export default function BottomNavigation({ userRole = 'learner', activeTab }: Props) {
  const router = useRouter();

  const handlePress = (route: string) => {
    // route paths assume your routing uses top-level routes like /dashboard, /courses etc.
    router.push(route as any);
  };

  return (
    <View style={styles.container} accessibilityRole="tablist">
      {tabs.map((tab) => (
        <TouchableOpacity
          key={tab.name}
          style={styles.tab}
          onPress={() => handlePress(tab.route)}
          accessibilityRole="tab"
          accessibilityState={{ selected: activeTab === tab.name }}
          accessibilityLabel={tab.label}
        >
          <Icon name={tab.icon} size={20} color={activeTab === tab.name ? '#ff6600' : '#999'} />
          <Text style={[styles.label, activeTab === tab.name && styles.labelActive]}>{tab.label}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#eee',
    paddingVertical: 10,
    justifyContent: 'space-around',
  },
  tab: {
    alignItems: 'center',
    width: 72,
  },
  label: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  labelActive: {
    color: '#ff6600',
    fontWeight: '700',
  },
});
