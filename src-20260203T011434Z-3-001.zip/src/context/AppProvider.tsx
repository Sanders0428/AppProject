import React, { useMemo, useState } from 'react';
import type { AppContextType, CourseType, UserType } from './AppContext';
import { AppContext } from './AppContext';


export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentScreen, setCurrentScreen] = useState<string>('splash');
  const [userRole, setUserRole] = useState<'learner' | 'admin' | null>(null);
  const [user, setUser] = useState<UserType | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<CourseType | null>(null);

  const enrollCourse = (course: CourseType) => {
    if (!user) return;
    const already = user.enrolledCourses?.some(c => c.id === course.id);
    if (already) return;
    const updated: UserType = {
      ...user,
      enrolledCourses: [...(user.enrolledCourses || []), { ...course, progress: 0 }],
    };
    setUser(updated);
  };

  const completeCourse = (courseId: string) => {
    if (!user) return;
    const course = user.enrolledCourses?.find(c => c.id === courseId);
    if (!course) return;
    const updated: UserType = {
      ...user,
      enrolledCourses: user.enrolledCourses?.filter(c => c.id !== courseId),
      completedCourses: [...(user.completedCourses || []), { ...course, progress: 100 }],
      certificates: [...(user.certificates || []), `Certificate for ${course.title}`],
    };
    setUser(updated);
  };

  const value: AppContextType = useMemo(
    () => ({
      currentScreen,
      setCurrentScreen,
      userRole,
      setUserRole,
      user,
      setUser,
      selectedCourse,
      setSelectedCourse,
      enrollCourse,
      completeCourse,
    }),
    [currentScreen, userRole, user, selectedCourse],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
};

export default AppProvider;
