// src/context/AppContext.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { User as FirebaseUser, getAuth, onAuthStateChanged } from 'firebase/auth';
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import api from '../lib/api';
import { verifyWithBackend } from '../lib/authService';

// --- Types (re-export or keep in a separate types file if you prefer) ---
export interface CourseType {
  id: string;
  title: string;
  description?: string;
  image?: string;
  mode?: string;
  enrolled?: boolean;
  instructor?: string;
  duration?: string;
  progress?: number;
}

export interface UserType {
  id?: string;
  fullName: string;
  role: 'learner' | 'admin';
  email: string;
  location?: string;
  enrolledCourses?: CourseType[];
  completedCourses?: CourseType[];
  certificates?: string[];
}

export interface AppContextType {
  currentScreen: string;
  setCurrentScreen: React.Dispatch<React.SetStateAction<string>>;
  userRole: 'learner' | 'admin' | null;
  setUserRole: (role: 'learner' | 'admin' | null) => void;
  user: UserType | null;
  setUser: React.Dispatch<React.SetStateAction<UserType | null>>;
  selectedCourse: CourseType | null;
  setSelectedCourse: React.Dispatch<React.SetStateAction<CourseType | null>>;
  enrollCourse: (course: CourseType) => void;
  completeCourse: (courseId: string) => void;
}

const ENROLLED_STORAGE_KEY = '@happytraining:enrolled_course_ids';

export const AppContext = React.createContext<AppContextType | null>(null);

export const AppProvider: React.FC<React.PropsWithChildren<{}>> = ({ children }) => {
  const [currentScreen, setCurrentScreen] = useState<string>('dashboard');
  const [userRole, setUserRole] = useState<'learner' | 'admin' | null>(null);
  const [user, setUser] = useState<UserType | null>(null);
  const [selectedCourse, setSelectedCourse] = useState<CourseType | null>(null);

  // derived enrolled ids
  const enrolledCourseIds = useMemo(() => user?.enrolledCourses?.map((c) => c.id) ?? [], [user?.enrolledCourses]);

  // Hydrate enrolled ids from AsyncStorage on mount if user has none yet
  useEffect(() => {
    const hydrate = async () => {
      try {
        const raw = await AsyncStorage.getItem(ENROLLED_STORAGE_KEY);
        if (raw) {
          const ids: string[] = JSON.parse(raw);
          if (ids.length && !user?.enrolledCourses?.length) {
            const minimal = ids.map((id) => ({ id, title: 'Course', enrolled: true } as CourseType));
            setUser((prev) => ({ ...(prev ?? {}), enrolledCourses: minimal } as UserType));
          }
        }
      } catch (err) {
        console.warn('Failed to hydrate enrolled ids', err);
      }
    };
    hydrate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Persist enrolled ids when they change
  useEffect(() => {
    const persist = async () => {
      try {
        const ids = user?.enrolledCourses?.map((c) => c.id) ?? [];
        await AsyncStorage.setItem(ENROLLED_STORAGE_KEY, JSON.stringify(ids));
      } catch (err) {
        console.warn('Failed to persist enrolled ids', err);
      }
    };
    persist();
  }, [user?.enrolledCourses]);

  // Listen to Firebase auth state and verify with backend
  useEffect(() => {
    const auth = getAuth();
    const unsub = onAuthStateChanged(auth, async (fbUser: FirebaseUser | null) => {
      if (fbUser) {
        // seed minimal firebase-backed user info
        setUser((prev) => ({
          ...(prev ?? {}),
          id: fbUser.uid,
          fullName: fbUser.displayName ?? prev?.fullName ?? '',
          email: fbUser.email ?? prev?.email ?? '',
        } as UserType));

        // verify with backend (verifyWithBackend uses api which attaches idToken)
        try {
          const backend = await verifyWithBackend();
          if (backend && typeof backend === 'object') {
            // merge backend fields into user and set role
            setUser((prev) => ({ ...(prev ?? {}), ...backend } as UserType));
            setUserRole((backend as any).role ?? null);
          } else {
            setUserRole(null);
          }
        } catch (err) {
          console.warn('Backend verification failed', err);
          setUserRole(null);
        }
      } else {
        // signed out
        setUser(null);
        setUserRole(null);
      }
    });

    return () => unsub();
  }, []);

  // enrollCourse: exposed as synchronous signature but runs async (fire-and-forget)
  const enrollCourseInternal = useCallback(
    async (course: CourseType) => {
      if (!user) {
        // no user signed in; do nothing — callers should guard
        return;
      }

      // optimistic local update
      setUser((prev) => {
        if (!prev) return prev;
        const exists = prev.enrolledCourses?.some((c) => c.id === course.id);
        if (exists) return prev;
        const next = [...(prev.enrolledCourses ?? []), { ...course, enrolled: true }];
        return { ...prev, enrolledCourses: next };
      });

      try {
        // call backend enroll endpoint
        await api.post(`/courses/${course.id}/enroll`);
      } catch (err) {
        console.error('Enroll API failed, rolling back', err);
        // rollback on failure
        setUser((prev) => {
          if (!prev) return prev;
          const next = (prev.enrolledCourses ?? []).filter((c) => c.id !== course.id);
          return { ...prev, enrolledCourses: next };
        });
      }
    },
    [user]
  );

  // completeCourse: marks complete locally and attempts backend update
  const completeCourseInternal = useCallback(
    async (courseId: string) => {
      if (!user) return;

      // optimistic update: remove from enrolled and add to completed
      setUser((prev) => {
        if (!prev) return prev;
        const enrolled = prev.enrolledCourses ?? [];
        const completed = prev.completedCourses ?? [];
        const found = enrolled.find((c) => c.id === courseId);
        const nextEnrolled = enrolled.filter((c) => c.id !== courseId);
        const nextCompleted = found ? [...completed, { ...found, progress: 100, enrolled: false }] : completed;
        return { ...prev, enrolledCourses: nextEnrolled, completedCourses: nextCompleted };
      });

      try {
        // backend API: update enrollment progress (adjust endpoint to your backend)
        await api.patch(`/enrollments/${courseId}/progress`, { progress: 100 });
      } catch (err) {
        console.error('Complete course API failed', err);
        // optionally re-fetch enrollments from backend or alert user
      }
    },
    [user]
  );

  // Exposed functions match your AppContextType (void-returning)
  const enrollCourse = useCallback((course: CourseType) => {
    void enrollCourseInternal(course);
  }, [enrollCourseInternal]);

  const completeCourse = useCallback((courseId: string) => {
    void completeCourseInternal(courseId);
  }, [completeCourseInternal]);

  // Build context value
  const contextValue: AppContextType = {
    currentScreen,
    setCurrentScreen,
    userRole,
    setUserRole,
    user,
    setUser,
    selectedCourse,
    setSelectedCourse,
    enrollCourse,
    completeCourse,
  };

  return <AppContext.Provider value={contextValue}>{children}</AppContext.Provider>;
};
