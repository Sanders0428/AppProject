// src/config/apiConfig.js

// Configuration for API and Firebase
const API_CONFIG = {
  development: {
    // 👇 Local backend URL
    // Use 10.0.2.2 instead of localhost for Android emulator
    baseURL: 'http://10.0.2.2:8080/api',

    // 👇 Firebase configuration from google-services.json
    firebaseConfig: {
      apiKey: "AIzaSyCdW58ns5jNo8jFuPiD2MwPVPv-T2cHipE",
      authDomain: "happy-training-and-consultancy.firebaseapp.com",
      projectId: "happy-training-and-consultancy",
      storageBucket: "happy-training-and-consultancy.firebasestorage.app",
      messagingSenderId: "1015466127824",
      appId: "1:1015466127824:android:661334b37a83e3651309d5"
    }
  },

  production: {
    // 👇 Replace with your deployed backend URL when you go live
    baseURL: 'https://your-production-domain.com/api',

    // 👇 You can reuse the same Firebase config for production,
    // or use a different Firebase project if you separate environments
    firebaseConfig: {
      apiKey: "AIzaSyCdW58ns5jNo8jFuPiD2MwPVPv-T2cHipE",
      authDomain: "happy-training-and-consultancy.firebaseapp.com",
      projectId: "happy-training-and-consultancy",
      storageBucket: "happy-training-and-consultancy.firebasestorage.app",
      messagingSenderId: "1015466127824",
      appId: "1:1015466127824:android:661334b37a83e3651309d5"
    }
  }
};

// Automatically choose environment based on Expo dev mode
const currentEnv = __DEV__ ? 'development' : 'production';

// Export constants for use throughout the app
export const API_BASE_URL = API_CONFIG[currentEnv].baseURL;
export const FIREBASE_CONFIG = API_CONFIG[currentEnv].firebaseConfig;

export default API_CONFIG;
