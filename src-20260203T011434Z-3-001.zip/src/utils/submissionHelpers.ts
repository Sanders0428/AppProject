import { SubmissionStatus } from '../constants/mockData';

// Return color based on submission status
export const getStatusColor = (status: SubmissionStatus): string => {
  switch (status) {
    case 'pending':
      return '#f59e0b'; // amber
    case 'reviewed':
      return '#10b981'; // green
    case 'late':
      return '#ef4444'; // red
    default:
      return '#ccc';
  }
};

// Return emoji icon based on status
export const getStatusIcon = (status: SubmissionStatus): string => {
  switch (status) {
    case 'pending':
      return '⌛';
    case 'reviewed':
      return '✅';
    case 'late':
      return '⚠️';
    default:
      return '';
  }
};

// Get initials from student name
export const getInitials = (name: string): string => {
  return name
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase();
};

// Calculate days late
export const getDaysLate = (submitted: Date, due: Date): number => {
  const diffTime = submitted.getTime() - due.getTime();
  return diffTime > 0 ? Math.ceil(diffTime / (1000 * 60 * 60 * 24)) : 0;
};
