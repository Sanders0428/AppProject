export type SubmissionStatus = 'pending' | 'reviewed' | 'late';

export interface Submission {
  id: string;
  studentName: string;
  assignment: string;
  course: string;
  status: SubmissionStatus;
  submittedDate: Date;
  dueDate: Date;
  grade?: string;
  files: string[];
}

// Example mock data
export const mockSubmissions: Submission[] = [
  {
    id: '1',
    studentName: 'Alice Mokoena',
    assignment: 'Math Project 1',
    course: 'Mathematics',
    status: 'pending',
    submittedDate: new Date('2025-10-25'),
    dueDate: new Date('2025-10-26'),
    files: ['math_project1.pdf'],
  },
  {
    id: '2',
    studentName: 'John Dlamini',
    assignment: 'History Essay',
    course: 'History',
    status: 'reviewed',
    submittedDate: new Date('2025-10-23'),
    dueDate: new Date('2025-10-24'),
    grade: 'A',
    files: ['history_essay.docx'],
  },
  {
    id: '3',
    studentName: 'Thabo Khumalo',
    assignment: 'Science Lab Report',
    course: 'Science',
    status: 'late',
    submittedDate: new Date('2025-10-28'),
    dueDate: new Date('2025-10-26'),
    files: ['lab_report.pdf'],
  },
];
