import { useRouter } from 'expo-router';
import React, { useContext, useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { AppContext, CourseType } from '../context/AppContext';
import CourseService from '../services/CourseService';

type ApiCourse = {
  id: string | number;
  title?: string;
  description?: string;
  image?: string;
  mode?: string;
  instructor?: string;
  duration?: string;
  price?: number;
};

export default function CoursesScreen() {
  const context = useContext(AppContext);
  const router = useRouter();

  const [courses, setCourses] = useState<ApiCourse[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [enrollingId, setEnrollingId] = useState<string | number | null>(null);

  useEffect(() => {
    loadCourses();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadCourses = async () => {
    try {
      setLoading(true);
      const response = await CourseService.getMobileCourses();
      const list = (response && (response as any).courses) || (response && (response as any).data) || response || [];
      setCourses(Array.isArray(list) ? list : []);
    } catch (error: unknown) {
      const msg = (error as any)?.message || String(error) || 'Failed to fetch courses';
      Alert.alert('Error', msg);
    } finally {
      setLoading(false);
    }
  };

  // Safely compute enrolled ids as strings
  const enrolledIds = new Set<string>(
    (context?.user?.enrolledCourses || []).map((c) => String(c.id))
  );

  const handleOpenDetails = (course: ApiCourse) => {
    if (!context) return;
    const courseId = String(course.id);
    const progress =
      context.user?.enrolledCourses?.find((ec) => String(ec.id) === courseId)?.progress ?? 0;

    const selected: CourseType = {
      id: courseId,
      title: course.title ?? 'Untitled course',
      description: course.description ?? '',
      image: course.image ?? '',
      mode: course.mode ?? 'self-paced',
      instructor: course.instructor ?? '',
      duration: course.duration ?? '',
      progress,
      enrolled: enrolledIds.has(courseId),
    };

    context.setSelectedCourse?.(selected);
    router.push('/course-details');
  };

  const handleEnroll = async (course: ApiCourse) => {
    if (!context?.user) {
      Alert.alert('Not signed in', 'Please log in or register to enroll in courses.');
      return;
    }

    const courseId = String(course.id);
    if (enrolledIds.has(courseId)) {
      router.push('/dashboard');
      return;
    }

    try {
      setEnrollingId(course.id);
      const res = await CourseService.enrollInCourse(courseId);

      context.enrollCourse?.({
        id: courseId,
        title: course.title ?? 'Untitled course',
        description: course.description ?? '',
        image: course.image ?? '',
        mode: course.mode ?? 'self-paced',
        instructor: course.instructor ?? '',
        duration: course.duration ?? '',
        progress: 0,
        enrolled: true,
      } as CourseType);

      Alert.alert('Enrolled', (res as any)?.message || `You have been enrolled in "${course.title}"`);
      await loadCourses();
    } catch (err: unknown) {
      const msg = (err as any)?.message || String(err) || 'Could not enroll in course';
      Alert.alert('Enrollment failed', msg);
    } finally {
      setEnrollingId(null);
    }
  };

  const renderItem = ({ item }: { item: ApiCourse }) => {
    const idKey = String(item.id);
    const isEnrolled = enrolledIds.has(idKey);

    return (
      <View style={styles.card}>
        <TouchableOpacity onPress={() => handleOpenDetails(item)} style={{ flex: 1 }}>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.desc}>{item.description}</Text>
          <Text style={styles.meta}>{item.duration ?? ''} • {item.mode ?? ''}</Text>
        </TouchableOpacity>

        <View style={styles.actions}>
          <TouchableOpacity
            style={[styles.button, isEnrolled ? styles.buttonSecondary : styles.buttonPrimary]}
            onPress={() => handleEnroll(item)}
            disabled={enrollingId === item.id}
          >
            {enrollingId === item.id ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.buttonText}>{isEnrolled ? 'Go to Dashboard' : 'Enroll'}</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={[styles.details, { marginLeft: 8 }]} onPress={() => handleOpenDetails(item)}>
            <Text style={styles.detailsText}>Details</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {loading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color="#003366" />
          <Text style={{ marginTop: 8 }}>Loading courses...</Text>
        </View>
      ) : (
        <FlatList
          data={courses}
          keyExtractor={(i) => String(i.id)}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 16 }}
          ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
          ListEmptyComponent={() => (
            <View style={styles.empty}>
              <Text style={styles.emptyText}>No courses available right now.</Text>
            </View>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  card: { backgroundColor: '#fff', padding: 14, borderRadius: 8, elevation: 2, marginBottom: 12 },
  title: { fontSize: 16, color: '#003366', fontWeight: '600' },
  desc: { fontSize: 13, color: '#444', marginTop: 6 },
  meta: { fontSize: 12, color: '#666', marginTop: 6 },
  actions: { flexDirection: 'row', marginTop: 12, justifyContent: 'flex-end', alignItems: 'center' },
  button: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 6 },
  buttonPrimary: { backgroundColor: '#ff6600' },
  buttonSecondary: { backgroundColor: '#10b981' },
  buttonText: { color: '#fff', fontWeight: '700' },
  details: { paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, borderWidth: 1, borderColor: '#003366' },
  detailsText: { color: '#003366', fontWeight: '600' },
  empty: { padding: 40, alignItems: 'center' },
  emptyText: { color: '#666' },
});
