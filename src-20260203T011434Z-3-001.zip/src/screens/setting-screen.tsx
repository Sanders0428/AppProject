// src/screens/SettingsScreen.tsx
import { useRouter } from 'expo-router';
import React, { useContext, useState } from 'react';
import { Alert, ScrollView, StyleSheet, Switch, Text, TextInput, TouchableOpacity, View } from 'react-native';
import BottomNavigation from '../components/BottomNavigation';
import { AppContext } from '../context/AppContext';

export default function SettingsScreen() {
  const context = useContext(AppContext);
  const router = useRouter();
  const user = context?.user;

  const [name, setName] = useState(user?.fullName ?? '');
  const [location, setLocation] = useState(user?.location ?? '');
  const [emailNotifications, setEmailNotifications] = useState<boolean>(true);

  if (!user) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>You must be signed in to view settings</Text>
      </View>
    );
  }

  const save = () => {
    if (!name.trim()) {
      Alert.alert('Please enter your name');
      return;
    }
    const updated = { ...user, fullName: name.trim(), location: location.trim() };
    context?.setUser?.(updated);
    Alert.alert('Saved', 'Profile settings updated');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Settings</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={styles.label}>Full name</Text>
          <TextInput style={styles.input} value={name} onChangeText={setName} placeholder="Full name" />
          <Text style={styles.label}>Location</Text>
          <TextInput style={styles.input} value={location} onChangeText={setLocation} placeholder="Location" />
          <Text style={styles.label}>Email</Text>
          <TextInput style={[styles.input, { backgroundColor: '#f5f5f5' }]} value={user.email} editable={false} />

          <TouchableOpacity style={styles.button} onPress={save}>
            <Text style={styles.buttonText}>Save changes</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Notifications</Text>
          <View style={styles.row}>
            <Text style={styles.label}>Email notifications</Text>
            <Switch value={emailNotifications} onValueChange={setEmailNotifications} />
          </View>
          <View style={styles.row}>
            <Text style={styles.label}>Dark theme (local)</Text>
            <Switch value={false} onValueChange={() => Alert.alert('Theme', 'Use global theme in AppContext')} />
          </View>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Support</Text>
          <TouchableOpacity style={styles.link} onPress={() => router.push('./support-screen')}>
            <Text style={styles.linkText}>Contact Support</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      <BottomNavigation userRole={user.role} activeTab="profile" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  content: { padding: 16, paddingBottom: 100 },
  card: { backgroundColor: '#fff', padding: 16, borderRadius: 10, marginBottom: 12 },
  label: { color: '#333', fontSize: 14, marginBottom: 6 },
  input: { backgroundColor: '#f7f9fb', padding: 12, borderRadius: 8, borderWidth: 1, borderColor: '#e6eef6', marginBottom: 12 },
  button: { backgroundColor: '#ff6600', padding: 12, borderRadius: 8, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '700' },
  sectionTitle: { fontSize: 16, color: '#003366', marginBottom: 10, fontWeight: '600' },
  row: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  link: { paddingVertical: 8 },
  linkText: { color: '#003366', fontWeight: '600' },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  emptyText: { color: '#666' },
});
