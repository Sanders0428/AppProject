// src/screens/SupportScreen.tsx
import { useRouter } from 'expo-router';
import React, { useContext, useState } from 'react';
import {
    Alert,
    KeyboardAvoidingView,
    Linking,
    Platform,
    ScrollView,
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
} from 'react-native';
import { AppContext } from '../context/AppContext';

export default function SupportScreen() {
  const router = useRouter();
  const context = useContext(AppContext);
  const user = context?.user;
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [faqOpen, setFaqOpen] = useState<number | null>(null);

  const faqs = [
    { q: 'How do I enroll in a course?', a: 'Open the Courses tab, select a course and tap Enroll.' },
    { q: 'Where are my certificates?', a: 'Certificates appear under your profile > Certificates when awarded.' },
    { q: 'How do I reset my password?', a: 'Use the Forgot password link on the Sign in screen to reset via email.' },
  ];

  const sendSupportEmail = async () => {
    if (!subject.trim() || !message.trim()) {
      Alert.alert('Missing details', 'Please add a subject and a message describing your issue.');
      return;
    }

    setLoading(true);
    try {
      const to = 'support@happytraining.co.za';
      const body = encodeURIComponent(
        `User: ${user?.email ?? 'anonymous'}\n\nMessage:\n${message.trim()}`
      );
      const mailto = `mailto:${to}?subject=${encodeURIComponent(subject.trim())}&body=${body}`;
      const canOpen = await Linking.canOpenURL(mailto);
      if (canOpen) {
        await Linking.openURL(mailto);
      } else {
        Alert.alert('Unable to open mail client', 'Please email support@happytraining.co.za directly.');
      }
    } catch (err) {
      Alert.alert('Error', 'Could not open mail client. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <View style={styles.headerRow}>
          <Text style={styles.title}>Support</Text>
          <TouchableOpacity onPress={() => router.back()}>
            <Text style={styles.link}>Back</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>Quick help</Text>
          {faqs.map((f, i) => (
            <View key={i} style={styles.faqItem}>
              <TouchableOpacity onPress={() => setFaqOpen(faqOpen === i ? null : i)} accessibilityRole="button">
                <View style={styles.faqRow}>
                  <Text style={styles.faqQ}>{f.q}</Text>
                  <Text style={styles.faqToggle}>{faqOpen === i ? '−' : '+'}</Text>
                </View>
              </TouchableOpacity>
              {faqOpen === i && <Text style={styles.faqA}>{f.a}</Text>}
            </View>
          ))}
        </View>

        <View style={styles.card}>
          <Text style={styles.label}>Contact support</Text>
          <TextInput
            value={subject}
            onChangeText={setSubject}
            placeholder="Subject"
            placeholderTextColor="#9aa3b2"
            style={styles.input}
            editable={!loading}
          />
          <TextInput
            value={message}
            onChangeText={setMessage}
            placeholder="Describe your issue or question"
            placeholderTextColor="#9aa3b2"
            style={[styles.input, styles.textArea]}
            editable={!loading}
            multiline
            textAlignVertical="top"
          />

          <TouchableOpacity
            style={[styles.button, loading && styles.buttonDisabled]}
            onPress={sendSupportEmail}
            disabled={loading}
            accessibilityRole="button"
          >
            <Text style={styles.buttonText}>{loading ? 'Preparing...' : 'Contact Support'}</Text>
          </TouchableOpacity>

          <View style={styles.helperRow}>
            <Text style={styles.helperText}>Or call us:</Text>
            <TouchableOpacity onPress={() => Linking.openURL('tel:+27123456789')}>
              <Text style={styles.phone}>+27 12 345 6789</Text>
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.card}>
          <TouchableOpacity style={styles.linkRow} onPress={() => Linking.openURL('https://termly.io/resources/templates/privacy-policy-template/')}>
  <Text style={styles.linkText}>Terms & Conditions</Text>
</TouchableOpacity>

<TouchableOpacity style={styles.linkRow} onPress={() => Linking.openURL('https://www.websitepolicies.com/blog/sample-privacy-policy-template')}>
  <Text style={styles.linkText}>Privacy policy</Text>
</TouchableOpacity>
        </View>
      </ScrollView>

      <View style={styles.bottomSpacer} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#f2f2f2' },
  container: { padding: 16, paddingBottom: 32 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  title: { fontSize: 20, color: '#003366', fontWeight: '700' },
  link: { color: '#003366', fontWeight: '600' },

  card: { backgroundColor: '#fff', padding: 14, borderRadius: 10, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 6, elevation: 1 },

  label: { color: '#003366', fontWeight: '600', marginBottom: 8 },

  faqItem: { marginBottom: 10 },
  faqRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  faqQ: { color: '#102030', fontSize: 14, flex: 1 },
  faqToggle: { color: '#003366', fontSize: 20, paddingLeft: 8 },
  faqA: { color: '#666', marginTop: 8 },

  input: { backgroundColor: '#f7f9fb', paddingHorizontal: 12, paddingVertical: 10, borderRadius: 8, borderWidth: 1, borderColor: '#e6eef6', color: '#102030', marginBottom: 12 },
  textArea: { height: 120 },

  button: { backgroundColor: '#ff6600', paddingVertical: 12, borderRadius: 10, alignItems: 'center' },
  buttonDisabled: { opacity: 0.6 },
  buttonText: { color: '#fff', fontWeight: '700' },

  helperRow: { marginTop: 12, flexDirection: 'row', alignItems: 'center' },
  helperText: { color: '#666', marginRight: 8 },
  phone: { color: '#003366', fontWeight: '700' },

  linkRow: { paddingVertical: 10 },
  linkText: { color: '#003366', fontWeight: '600' },

  bottomSpacer: { height: 80 },
});
