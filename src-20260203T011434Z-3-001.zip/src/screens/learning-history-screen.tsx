// src/screens/LearningHistoryScreen.tsx
import { useRouter } from 'expo-router';
import React, { useContext } from 'react';
import { FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import BottomNavigation from '../components/BottomNavigation';
import { AppContext } from '../context/AppContext';

export default function LearningHistoryScreen() {
  const context = useContext(AppContext);
  const router = useRouter();
  const user = context?.user;

  if (!user) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>Sign in to view learning history</Text>
      </View>
    );
  }

  // Example: use enrolled/completed courses arrays on user
  const completed = user.completedCourses || [];
  const enrolled = user.enrolledCourses || [];

  const renderCompleted = ({ item }: any) => (
    <View style={styles.item}>
      <Text style={styles.itemTitle}>{item.title ?? 'Course'}</Text>
      <Text style={styles.itemSub}>{item.completedOn ?? 'Completed date unknown'}</Text>
      <TouchableOpacity style={styles.detailBtn} onPress={() => router.push(`/course-details?id=${item.id}`)}>
        <Text style={styles.detailText}>Open</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Learning History</Text>
      </View>

      <FlatList
        contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
        data={completed}
        keyExtractor={(i: any) => String(i.id ?? i.title)}
        renderItem={renderCompleted}
        ListEmptyComponent={() => (
          <View style={styles.empty}>
            <Text style={styles.emptyText}>You have no completed courses yet</Text>
            {enrolled.length > 0 && <Text style={styles.hint}>Continue your enrolled courses to earn certificates</Text>}
          </View>
        )}
      />

      <BottomNavigation userRole={user.role} activeTab="profile" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  item: { backgroundColor: '#fff', padding: 12, borderRadius: 10, marginBottom: 12 },
  itemTitle: { fontSize: 16, color: '#003366', fontWeight: '700' },
  itemSub: { color: '#666', marginTop: 6 },
  detailBtn: { marginTop: 8, backgroundColor: '#ff6600', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 8, alignSelf: 'flex-start' },
  detailText: { color: '#fff', fontWeight: '700' },
  empty: { padding: 40, alignItems: 'center' },
  emptyText: { color: '#666' },
  hint: { color: '#999', marginTop: 8, textAlign: 'center' },
});
