// src/screens/CertificatesScreen.tsx
import React, { useContext } from 'react';
import { FlatList, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import BottomNavigation from '../components/BottomNavigation';
import { AppContext } from '../context/AppContext';

export default function CertificatesScreen() {
  const context = useContext(AppContext);
  const user = context?.user;

  if (!user) {
    return (
      <View style={styles.empty}>
        <Text style={styles.emptyText}>Sign in to view your certificates</Text>
      </View>
    );
  }

  // sample certificates array on user.certificates (if backend provides them)
  const certificates = user.certificates || [
    // fallback sample items if empty
    // { id: 'c1', title: 'First Aid', issuedOn: '2024-07-01', image: null }
  ];

  const renderItem = ({ item }: any) => (
    <View style={styles.card}>
      <View style={styles.row}>
        <Image source={item.image ? { uri: item.image } : require('../../assets/images/certificate-placeholder.png')} style={styles.thumb} />
        <View style={{ flex: 1, marginLeft: 12 }}>
          <Text style={styles.title}>{item.title ?? 'Certificate'}</Text>
          <Text style={styles.sub}>{item.issuedOn ? `Issued ${item.issuedOn}` : '—'}</Text>
        </View>
        <TouchableOpacity style={styles.viewBtn}>
          <Text style={styles.viewText}>View</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Certificates</Text>
      </View>

      <FlatList
        contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
        data={certificates}
        keyExtractor={(i: any) => String(i.id ?? i.title)}
        renderItem={renderItem}
        ListEmptyComponent={() => (
          <View style={styles.empty}>
            <Text style={styles.emptyText}>No certificates yet</Text>
          </View>
        )}
      />

      <BottomNavigation userRole={user.role} activeTab="profile" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  card: { backgroundColor: '#fff', padding: 12, borderRadius: 10, marginBottom: 12 },
  row: { flexDirection: 'row', alignItems: 'center' },
  thumb: { width: 64, height: 44, resizeMode: 'cover', borderRadius: 6, backgroundColor: '#eee' },
  title: { fontSize: 16, color: '#003366', fontWeight: '700' },
  sub: { color: '#666', marginTop: 4 },
  viewBtn: { paddingVertical: 6, paddingHorizontal: 10, backgroundColor: '#003366', borderRadius: 6 },
  viewText: { color: '#fff', fontWeight: '700' },
  empty: { padding: 40, alignItems: 'center' },
  emptyText: { color: '#666' },
});
