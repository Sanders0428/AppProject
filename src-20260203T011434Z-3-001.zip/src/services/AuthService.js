// src/services/AuthService.js
// Authentication helpers: signIn, signUp, signOut, getCurrentUser and token utilities.
// Works with Firebase Auth and also returns normalized error objects.

import {
  createUserWithEmailAndPassword,
  signOut as firebaseSignOut,
  signInWithEmailAndPassword,
} from 'firebase/auth';
import { auth } from '../firebase';
import apiClient from './apiClient';

async function getIdToken() {
  try {
    const user = auth?.currentUser;
    if (!user || typeof user.getIdToken !== 'function') return null;
    return await user.getIdToken();
  } catch (err) {
    return null;
  }
}

class AuthService {
  // Firebase email/password sign up
  async registerWithEmail(email, password) {
    try {
      const res = await createUserWithEmailAndPassword(auth, email, password);
      return { uid: res.user.uid, email: res.user.email };
    } catch (err) {
      throw this._handleError(err);
    }
  }

  // Firebase email/password sign in
  async signInWithEmail(email, password) {
    try {
      const res = await signInWithEmailAndPassword(auth, email, password);
      // return basic user info and id token if available
      const token = await getIdToken();
      return { uid: res.user.uid, email: res.user.email, token };
    } catch (err) {
      throw this._handleError(err);
    }
  }

  // Sign out from Firebase
  async signOut() {
    try {
      await firebaseSignOut(auth);
      return { success: true };
    } catch (err) {
      throw this._handleError(err);
    }
  }

  // Get current firebase user (normalized) and token if available
  async getCurrentUser() {
    try {
      const user = auth?.currentUser;
      if (!user) return null;
      const token = await getIdToken();
      return { uid: user.uid, email: user.email, token };
    } catch (err) {
      throw this._handleError(err);
    }
  }

  // Optionally call backend to create/refresh app user record
  async createOrUpdateAppUser(payload = {}) {
    try {
      const token = await getIdToken();
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await apiClient.post('/auth/user', payload, { headers });
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  // Optional: validate token with backend
  async validateToken() {
    try {
      const token = await getIdToken();
      if (!token) return null;
      const res = await apiClient.get('/auth/validate', { headers: { Authorization: `Bearer ${token}` } });
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  _handleError(err) {
    if (err?.response?.data) {
      const message = err.response.data.message || err.response.data.error || JSON.stringify(err.response.data);
      const status = err.response.status;
      return { message, status, raw: err };
    }
    // Firebase errors often come with code/message
    if (err?.code || err?.message) {
      return { message: err.message || err.code, raw: err };
    }
    return { message: err?.toString() || 'Unexpected error', raw: err };
  }
}

export default new AuthService();
