// src/services/apiClient.js
import axios from 'axios';
import { auth } from '../firebase';

// Create axios instance with sensible defaults
const apiClient = axios.create({
  baseURL: process.env.API_BASE_URL || 'https://api.happytraining.co.za', // adjust as needed
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// Attach Firebase ID token to requests when available
apiClient.interceptors.request.use(
  async (config) => {
    try {
      const user = auth?.currentUser;
      if (user && typeof user.getIdToken === 'function') {
        const token = await user.getIdToken();
        if (token) {
          config.headers = {
            ...config.headers,
            Authorization: `Bearer ${token}`,
          };
        }
      }
    } catch (e) {
      // silence token retrieval errors; request will continue without Authorization header
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor to normalize errors
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response) {
      // Server responded with a status outside 2xx
      const normalized = {
        status: error.response.status,
        data: error.response.data,
        message:
          (error.response.data && (error.response.data.message || error.response.data.error)) ||
          error.response.statusText ||
          'Request failed',
      };
      return Promise.reject(normalized);
    }
    if (error.request) {
      // Request made but no response
      return Promise.reject({ message: 'No response from server', raw: error });
    }
    // Something else happened
    return Promise.reject({ message: error.message || 'Network error', raw: error });
  }
);

export default apiClient;
