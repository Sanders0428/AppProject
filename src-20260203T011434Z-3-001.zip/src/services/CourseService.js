// src/services/CourseService.js
// Improved CourseService with error handling and optional Firebase auth token support.

import { auth } from '../firebase';
import apiClient from './apiClient';

/**
 * Helper to get current user's ID token (if using Firebase auth).
 * Returns null if no user/token available.
 */
async function getIdToken() {
  try {
    const user = auth?.currentUser;
    if (!user || !user.getIdToken) return null;
    const token = await user.getIdToken();
    return token;
  } catch (err) {
    // fail silently and allow unauthenticated requests to proceed if applicable
    return null;
  }
}

class CourseService {
  async getAllCourses() {
    try {
      const res = await apiClient.get('/courses');
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  async getCourseById(courseId) {
    try {
      const res = await apiClient.get(`/courses/${courseId}`);
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  async getMobileCourses() {
    try {
      const res = await apiClient.get('/mobile/courses');
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  async enrollInCourse(courseId) {
    try {
      const token = await getIdToken();
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await apiClient.post(`/mobile/enroll/${courseId}`, null, { headers });
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  async getUserCourses() {
    try {
      const token = await getIdToken();
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await apiClient.get('/mobile/my-courses', { headers });
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  // Optional helper: enroll multiple courses in one request
  async enrollMultiple(courseIds = []) {
    try {
      const token = await getIdToken();
      const headers = token ? { Authorization: `Bearer ${token}` } : {};
      const res = await apiClient.post('/mobile/enroll', { courseIds }, { headers });
      return res.data;
    } catch (err) {
      throw this._handleError(err);
    }
  }

  _handleError(err) {
    // Normalize error object for callers
    if (err?.response?.data) {
      const message = err.response.data.message || err.response.data.error || JSON.stringify(err.response.data);
      const status = err.response.status;
      return { message, status, raw: err };
    }
    return { message: err.message || 'Network error', raw: err };
  }
}

export default new CourseService();
