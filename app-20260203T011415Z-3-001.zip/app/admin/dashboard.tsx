import { Feather } from '@expo/vector-icons';
import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

import { useRouter } from 'expo-router';

interface StatCard {
  icon: keyof typeof Feather.glyphMap;
  label: string;
  value: number;
  color: string;
}

interface Activity {
  id: string;
  description: string;
  time: string;
}

const AdminDashboard = () => {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState<StatCard[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);

  useEffect(() => {
    setTimeout(() => {
      setStats([
        { icon: 'users', label: 'Learners', value: 128, color: '#4CAF50' },
        { icon: 'book-open', label: 'Courses', value: 24, color: '#FF9800' },
        { icon: 'upload', label: 'Submissions', value: 57, color: '#2196F3' },
        { icon: 'calendar', label: 'Events', value: 6, color: '#9C27B0' },
      ]);

      setActivities([
        { id: '1', description: 'New course "Digital Skills 101" added', time: '2h ago' },
        { id: '2', description: '5 learners registered', time: '5h ago' },
        { id: '3', description: 'Assessment uploaded for “Java Basics”', time: '1d ago' },
        { id: '4', description: 'Calendar updated for November', time: '2d ago' },
      ]);

      setLoading(false);
    }, 1500);
  }, []);

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#003366" />
        <Text style={{ marginTop: 10, color: '#003366' }}>Loading dashboard...</Text>
      </View>
    );
  }

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Admin Dashboard</Text>
      <Text style={styles.subtitle}>Welcome back, Administrator 👋</Text>

      {/* Stats Grid */}
      <View style={styles.grid}>
        {stats.map((item, index) => (
          <View key={index} style={[styles.card, { backgroundColor: item.color }]}>
            <Feather name={item.icon} size={28} color="#fff" />
            <Text style={styles.cardValue}>{item.value}</Text>
            <Text style={styles.cardText}>{item.label}</Text>
          </View>
        ))}
      </View>

      {/* Recent Activity */}
      <View style={styles.activityContainer}>
        <Text style={styles.activityTitle}>Recent Activity</Text>
        {activities.map((activity) => (
          <View key={activity.id} style={styles.activityItem}>
            <Feather name="clock" size={18} color="#666" style={{ marginRight: 8 }} />
            <View>
              <Text style={styles.activityText}>{activity.description}</Text>
              <Text style={styles.activityTime}>{activity.time}</Text>
            </View>
          </View>
        ))}
      </View>

      {/* Navigation Button */}
      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={styles.manageBtn}
          onPress={() => router.push('../app/admin/manage-courses')}
        >
          <Feather name="settings" size={20} color="#fff" />
          <Text style={styles.manageText}>Manage Courses</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

export default AdminDashboard;

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f8fa',
  },
  container: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    backgroundColor: '#f5f8fa',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#003366',
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginBottom: 30,
  },
  grid: {
    width: '100%',
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: '47%',
    borderRadius: 12,
    paddingVertical: 20,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  cardValue: {
    fontSize: 22,
    color: '#fff',
    fontWeight: '700',
    marginTop: 8,
  },
  cardText: {
    color: '#fff',
    fontSize: 14,
    marginTop: 4,
  },
  activityContainer: {
    width: '100%',
    marginTop: 20,
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
  },
  activityTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#003366',
    marginBottom: 10,
  },
  activityItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  activityText: {
    fontSize: 15,
    color: '#333',
  },
  activityTime: {
    fontSize: 12,
    color: '#888',
  },
  buttonContainer: {
    width: '100%',
    marginTop: 30,
    alignItems: 'center',
  },
  manageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#003366',
    borderRadius: 10,
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  manageText: {
    color: '#fff',
    fontWeight: '600',
    marginLeft: 8,
  },
});
