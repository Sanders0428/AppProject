import { Feather as Icon } from '@expo/vector-icons';
import React, { useContext, useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import BottomNavigation from '../../src/components/BottomNavigation';
import { AppContext } from '../../src/context/AppContext';

import { useRouter } from 'expo-router';

type Course = {
  id: string;
  title: string;
  description: string;
  mode: 'online' | 'in-person' | 'hybrid';
  image?: string;
  instructor: string;
  duration: string;
  enrolled: boolean;
};

const ManageCourses = () => {
  const context = useContext(AppContext);
  const router = useRouter();

  const [searchQuery, setSearchQuery] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  const [courses, setCourses] = useState<Course[]>([
    {
      id: '1',
      title: 'Digital Marketing Basics',
      description: 'Learn the fundamentals of digital marketing including social media, SEO, and content marketing.',
      mode: 'online',
      image: '',
      instructor: 'Dr. Sarah Mitchell',
      duration: '6 weeks',
      enrolled: true,
    },
    {
      id: '2',
      title: 'Business Communication Skills',
      description: 'Develop professional communication skills for workplace success.',
      mode: 'hybrid',
      image: '',
      instructor: 'Prof. Michael Roberts',
      duration: '4 weeks',
      enrolled: false,
    },
    {
      id: '3',
      title: 'Project Management Fundamentals',
      description: 'Master the basics of project management and team leadership.',
      mode: 'in-person',
      image: '',
      instructor: 'Lisa Thompson',
      duration: '8 weeks',
      enrolled: false,
    },
  ]);

  const [newTitle, setNewTitle] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newDuration, setNewDuration] = useState('');
  const [newMode, setNewMode] = useState<Course['mode']>('online');
  const [newInstructor, setNewInstructor] = useState('');

  const filteredCourses = courses.filter(course =>
    course.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleBack = () => {
    router.push('../app/admin/dashboard');
  };

  const handleEditCourse = (course: Course) => {
    Alert.alert('Edit Course', `Edit course: ${course.title}`);
  };

  const handleDeleteCourse = (id: string) => {
    Alert.alert('Delete Course', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        onPress: () => setCourses(prev => prev.filter(c => c.id !== id)),
      },
    ]);
  };

  const getModeColor = (mode: Course['mode']) => {
    switch (mode) {
      case 'online': return '#bbf7d0';
      case 'in-person': return '#bfdbfe';
      case 'hybrid': return '#e9d5ff';
      default: return '#ccc';
    }
  };

  const handleCreateCourse = () => {
    if (!newTitle || !newDescription || !newDuration || !newInstructor) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    const newCourse: Course = {
      id: Date.now().toString(),
      title: newTitle,
      description: newDescription,
      duration: newDuration,
      mode: newMode,
      instructor: newInstructor,
      enrolled: false,
    };

    setCourses(prev => [...prev, newCourse]);

    setNewTitle('');
    setNewDescription('');
    setNewDuration('');
    setNewMode('online');
    setNewInstructor('');
    setShowAddForm(false);

    Alert.alert('Success', 'Course added successfully!');
  };

  if (showAddForm) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => setShowAddForm(false)}>
            <Icon name="arrow-left" size={24} color="#fff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Add New Course</Text>
        </View>

        <ScrollView contentContainerStyle={styles.form}>
          <TextInput
            style={styles.input}
            placeholder="Course Title"
            value={newTitle}
            onChangeText={setNewTitle}
          />
          <TextInput
            style={styles.textarea}
            placeholder="Description"
            multiline
            numberOfLines={3}
            value={newDescription}
            onChangeText={setNewDescription}
          />
          <View style={styles.row}>
            <TextInput
              style={[styles.input, styles.half]}
              placeholder="Duration"
              value={newDuration}
              onChangeText={setNewDuration}
            />
            <TextInput
              style={[styles.input, styles.half]}
              placeholder="Mode (online/in-person/hybrid)"
              value={newMode}
              onChangeText={text => {
                if (['online', 'in-person', 'hybrid'].includes(text)) {
                  setNewMode(text as Course['mode']);
                }
              }}
            />
          </View>
          <TextInput
            style={styles.input}
            placeholder="Instructor"
            value={newInstructor}
            onChangeText={setNewInstructor}
          />
          <TouchableOpacity style={styles.button} onPress={handleCreateCourse}>
            <Text style={styles.buttonText}>Create Course</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.buttonOutline} onPress={() => setShowAddForm(false)}>
            <Text style={styles.buttonOutlineText}>Cancel</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Courses</Text>
        <TouchableOpacity style={styles.addButton} onPress={() => setShowAddForm(true)}>
          <Icon name="plus" size={16} color="#fff" />
          <Text style={styles.addButtonText}>Add Course</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.searchBar}>
        <Icon name="search" size={16} color="#666" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search courses..."
          value={searchQuery}
          onChangeText={setSearchQuery}
        />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {filteredCourses.map(course => (
          <View key={course.id} style={styles.card}>
            <Text style={styles.cardTitle}>{course.title}</Text>
            <Text style={styles.cardDescription}>{course.description}</Text>
            <Text style={styles.cardMeta}>Instructor: {course.instructor}</Text>
            <Text style={styles.cardMeta}>Duration: {course.duration}</Text>
            <Text style={[styles.modeBadge, { backgroundColor: getModeColor(course.mode) }]}>
              {course.mode}
            </Text>
            <View style={styles.actions}>
              <TouchableOpacity style={styles.editButton} onPress={() => handleEditCourse(course)}>
                <Icon name="edit" size={16} color="#003366" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteButton} onPress={() => handleDeleteCourse(course.id)}>
                <Icon name="trash-2" size={16} color="#c00" />
              </TouchableOpacity>
            </View>
          </View>
        ))}
        {filteredCourses.length === 0 && <Text style={styles.empty}>No courses found.</Text>}
      </ScrollView>

      <BottomNavigation userRole="admin" activeTab="courses" />
    </View>
  );
};

export default ManageCourses;
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between', 
    backgroundColor: '#003366', 
    padding: 16 
  },
  headerTitle: { color: '#fff', fontSize: 18 },
  addButton: { flexDirection: 'row', backgroundColor: '#ff6600', padding: 8, borderRadius: 6 },
  addButtonText: { color: '#fff', marginLeft: 6 },
  searchBar: { flexDirection: 'row', alignItems: 'center', padding: 10, backgroundColor: '#fff', margin: 16, borderRadius: 6 },
  searchIcon: { marginRight: 8 },
  searchInput: { flex: 1, fontSize: 14 },
  content: { padding: 16 },
  card: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 12 },
  cardTitle: { fontSize: 16, color: '#003366', marginBottom: 4 },
  cardDescription: { fontSize: 14, color: '#555', marginBottom: 4 },
  cardMeta: { fontSize: 12, color: '#666', marginBottom: 2 },
  modeBadge: { fontSize: 12, color: '#003366', padding: 4, borderRadius: 6, marginTop: 4 },
  actions: { flexDirection: 'row', marginTop: 10 },
  editButton: { marginRight: 10, padding: 6, borderWidth: 1, borderColor: '#003366', borderRadius: 6 },
  deleteButton: { padding: 6, borderWidth: 1, borderColor: '#c00', borderRadius: 6 },
  empty: { textAlign: 'center', color: '#666', marginTop: 40 },
  form: { padding: 16 },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 6, padding: 10, marginBottom: 12 },
  textarea: { borderWidth: 1, borderColor: '#ccc', borderRadius: 6, padding: 10, marginBottom: 12, textAlignVertical: 'top' },
  row: { flexDirection: 'row', justifyContent: 'space-between' },
  half: { width: '48%' },
  button: { backgroundColor: '#ff6600', padding: 12, borderRadius: 6, marginBottom: 10 },
  buttonText: { color: '#fff', textAlign: 'center' },
  buttonOutline: { borderWidth: 1, borderColor: '#003366', padding: 12, borderRadius: 6, marginBottom: 10 },
  buttonOutlineText: { color: '#003366', textAlign: 'center' },
});
