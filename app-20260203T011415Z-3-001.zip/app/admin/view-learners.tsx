import { Feather as Icon } from '@expo/vector-icons';
import React, { useContext, useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { AppContext } from '../../src/context/AppContext';

import { useRouter } from 'expo-router';

type LearnerStatus = 'active' | 'inactive';

interface Learner {
  id: string;
  fullName: string;
  email: string;
  location: string;
  joinDate: Date;
  coursesEnrolled: number;
  coursesCompleted: number;
  status: LearnerStatus;
}

const mockLearners: Learner[] = [
  {
    id: '1',
    fullName: 'John Smith',
    email: 'john.smith@email.com',
    location: 'Cape Town, South Africa',
    joinDate: new Date(2024, 1, 15),
    coursesEnrolled: 3,
    coursesCompleted: 1,
    status: 'active',
  },
  {
    id: '2',
    fullName: 'Sarah Johnson',
    email: 'sarah.johnson@email.com',
    location: 'Johannesburg, South Africa',
    joinDate: new Date(2024, 0, 28),
    coursesEnrolled: 2,
    coursesCompleted: 2,
    status: 'active',
  },
  {
    id: '3',
    fullName: 'Michael Brown',
    email: 'michael.brown@email.com',
    location: 'Durban, South Africa',
    joinDate: new Date(2023, 11, 10),
    coursesEnrolled: 4,
    coursesCompleted: 3,
    status: 'active',
  },
  {
    id: '4',
    fullName: 'Lisa Davis',
    email: 'lisa.davis@email.com',
    location: 'Pretoria, South Africa',
    joinDate: new Date(2024, 2, 5),
    coursesEnrolled: 1,
    coursesCompleted: 0,
    status: 'inactive',
  },
];

const ViewLearners: React.FC = () => {
  const context = useContext(AppContext);
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | LearnerStatus>('all');

  const handleBack = () => {
    router.push('../app/admin/dashboard');
  };

  const filteredLearners = mockLearners.filter(learner => {
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      q === '' ||
      learner.fullName.toLowerCase().includes(q) ||
      learner.email.toLowerCase().includes(q);
    const matchesFilter = filterStatus === 'all' || learner.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  const getInitials = (name: string) =>
    name
      .split(' ')
      .filter(Boolean)
      .map(word => word[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();

  const getStatusColor = (status: LearnerStatus) =>
    status === 'active' ? '#bbf7d0' : '#e5e7eb';

  const onAction = (title: string, id: string) => {
    Alert.alert(title, `Learner ID: ${id}`);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>View Learners</Text>
      </View>

      {/* Search and Filter */}
      <View style={styles.searchSection}>
        <View style={styles.searchBar}>
          <Icon name="search" size={16} color="#666" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search learners..."
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
          />
        </View>

        <View style={styles.filterRow}>
          {(['all', 'active', 'inactive'] as const).map(status => (
            <TouchableOpacity
              key={status}
              style={[
                styles.filterButton,
                filterStatus === status && styles.filterActive,
              ]}
              onPress={() => setFilterStatus(status)}
            >
              <Text
                style={[
                  styles.filterText,
                  filterStatus === status && styles.filterTextActive,
                ]}
              >
                {status.charAt(0).toUpperCase() + status.slice(1)} (
                {status === 'all'
                  ? mockLearners.length
                  : mockLearners.filter(l => l.status === status).length}
                )
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Content */}
      <ScrollView contentContainerStyle={styles.content}>
        {filteredLearners.map(learner => (
          <View key={learner.id} style={styles.card}>
            <View style={styles.cardHeader}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{getInitials(learner.fullName)}</Text>
              </View>
              <View style={styles.cardInfo}>
                <Text style={styles.name}>{learner.fullName}</Text>
                <Text style={[styles.statusBadge, { backgroundColor: getStatusColor(learner.status) }]}>
                  {learner.status}
                </Text>
              </View>
              <TouchableOpacity onPress={() => onAction('More actions', learner.id)}>
                <Icon name="more-vertical" size={16} color="#666" />
              </TouchableOpacity>
            </View>

            <Text style={styles.meta}>📧 {learner.email}</Text>
            <Text style={styles.meta}>📍 {learner.location}</Text>
            <Text style={styles.meta}>📅 Joined {learner.joinDate.toLocaleDateString()}</Text>

            <View style={styles.statsRow}>
              <View style={styles.statBox}>
                <Text style={styles.statValue}>{learner.coursesEnrolled}</Text>
                <Text style={styles.statLabel}>Enrolled</Text>
              </View>
              <View style={styles.statBox}>
                <Text style={styles.statValue}>{learner.coursesCompleted}</Text>
                <Text style={styles.statLabel}>Completed</Text>
              </View>
            </View>

            <View style={styles.actions}>
              <TouchableOpacity
                style={styles.messageButton}
                onPress={() => onAction('Send message', learner.id)}
              >
                <Icon name="mail" size={14} color="#fff" />
                <Text style={styles.messageText}>Message</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.profileButton}
                onPress={() => onAction('View profile', learner.id)}
              >
                <Text style={styles.profileText}>View Profile</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
        {filteredLearners.length === 0 && (
          <Text style={styles.empty}>No learners found matching your criteria.</Text>
        )}
      </ScrollView>
    </View>
  );
};

export default ViewLearners;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18, marginLeft: 10 },
  searchSection: { padding: 16 },
  searchBar: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 6, paddingHorizontal: 10, marginBottom: 10 },
  searchIcon: { marginRight: 8 },
  searchInput: { flex: 1, fontSize: 14, paddingVertical: 8 },
  filterRow: { flexDirection: 'row', justifyContent: 'space-between' },
  filterButton: { padding: 8, borderRadius: 6, backgroundColor: '#fff', marginRight: 8 },
  filterActive: { backgroundColor: '#ff6600' },
  filterText: { fontSize: 12, color: '#003366' },
  filterTextActive: { color: '#fff' },
  content: { padding: 16, paddingBottom: 32 },
  card: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 12 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  avatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#ff6600', justifyContent: 'center', alignItems: 'center' },
  avatarText: { color: '#fff', fontWeight: 'bold' },
  cardInfo: { flex: 1, marginLeft: 10 },
  name: { fontSize: 16, color: '#003366' },
  statusBadge: { fontSize: 12, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6, marginTop: 4, alignSelf: 'flex-start' },
  meta: { fontSize: 12, color: '#666', marginBottom: 2 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
  statBox: { backgroundColor: '#e0f2fe', padding: 10, borderRadius: 6, width: '48%', alignItems: 'center' },
  statValue: { fontSize: 18, fontWeight: '700', color: '#003366' },
  statLabel: { fontSize: 12, color: '#065f46' },
  actions: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 12 },
  messageButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#003366', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 6 },
  messageText: { color: '#fff', marginLeft: 8, fontWeight: '600' },
  profileButton: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#003366', paddingHorizontal: 12, paddingVertical: 8, borderRadius: 6 },
  profileText: { color: '#003366', fontWeight: '600' },
  empty: { textAlign: 'center', color: '#666', marginTop: 20 },
});