import { Feather as Icon } from '@expo/vector-icons';
import React, { useContext } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import BottomNavigation from '../../src/components/BottomNavigation';
import { AppContext } from '../../src/context/AppContext';

import { useRouter } from 'expo-router';

const mockAdminEvents = [{
  id: '1',
  title: 'Digital Marketing Module 3 Exam',
  date: new Date(2025, 2, 18),
  time: '14:00',
  type: 'exam',
  course: 'Digital Marketing Basics',
},
  {
    id: '2',
    title: 'Project Management Workshop',
    date: new Date(2025, 2, 20),
    time: '10:00',
    type: 'class',
    course: 'Project Management Fundamentals',
    location: 'Conference Room A',
  },
  {
    id: '3',
    title: 'Assignment Deadline - Business Plan',
    date: new Date(2025, 2, 22),
    time: '23:59',
    type: 'deadline',
    course: 'Financial Literacy',
  },
  {
    id: '4',
    title: 'Faculty Meeting',
    date: new Date(2025, 2, 25),
    time: '15:30',
    type: 'meeting',
    location: 'Admin Building',
  },
];

const ManageCalendar = () => {
  const context = useContext(AppContext);
  const router = useRouter();

  const handleBack = () => {
    router.push('../app/admin/dashboard'); 
  };

  const handleAddEvent = () => {
    Alert.alert('Add Event', 'Add new event functionality');
  };

  const handleEditEvent = (id: string) => {
    Alert.alert('Edit Event', `Edit event: ${id}`);
  };

  const handleDeleteEvent = (id: string) => {
    Alert.alert('Delete Event', 'Are you sure?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', onPress: () => Alert.alert('Deleted', `Event deleted: ${id}`) },
    ]);
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'assignment': return '#bfdbfe';
      case 'exam': return '#fecaca';
      case 'class': return '#bbf7d0';
      case 'deadline': return '#fed7aa';
      case 'meeting': return '#e9d5ff';
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'assignment': return '📝';
      case 'exam': return '📊';
      case 'class': return '🎓';
      case 'deadline': return '⏰';
      case 'meeting': return '👥';
    }
  };

  const sortedEvents = mockAdminEvents.sort((a, b) => a.date.getTime() - b.date.getTime());

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Manage Calendar</Text>
        <TouchableOpacity style={styles.addButton} onPress={handleAddEvent}>
          <Icon name="plus" size={16} color="#fff" />
          <Text style={styles.addButtonText}>Add Event</Text>
        </TouchableOpacity>
      </View>

      {/* Content */}
      <ScrollView contentContainerStyle={styles.content}>
        {sortedEvents.map(event => (
          <View key={event.id} style={[styles.card, { backgroundColor: getColor(event.type) }]}>
            <View style={styles.cardHeader}>
              <Text style={styles.eventIcon}>{getIcon(event.type)}</Text>
              <Text style={styles.eventTitle}>{event.title}</Text>
            </View>
            <Text style={styles.eventMeta}>📅 {event.date.toLocaleDateString()}</Text>
            <Text style={styles.eventMeta}>⏰ {event.time}</Text>
            {event.course && <Text style={styles.eventMeta}>📘 {event.course}</Text>}
            {event.location && <Text style={styles.eventMeta}>📍 {event.location}</Text>}
            <View style={styles.actions}>
              <TouchableOpacity style={styles.editButton} onPress={() => handleEditEvent(event.id)}>
                <Icon name="edit" size={16} color="#003366" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.deleteButton} onPress={() => handleDeleteEvent(event.id)}>
                <Icon name="trash-2" size={16} color="#c00" />
              </TouchableOpacity>
            </View>
          </View>
        ))}

        {/* Quick Add */}
        <View style={styles.quickAdd}>
          <Text style={styles.quickAddTitle}>Quick Add Events</Text>
          <View style={styles.quickGrid}>
            <TouchableOpacity style={[styles.quickButton, { borderColor: '#3b82f6' }]} onPress={() => Alert.alert('Add assignment')}>
              <Text style={{ color: '#3b82f6' }}>📝 Assignment</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.quickButton, { borderColor: '#ef4444' }]} onPress={() => Alert.alert('Add exam')}>
              <Text style={{ color: '#ef4444' }}>📊 Exam</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.quickButton, { borderColor: '#10b981' }]} onPress={() => Alert.alert('Add class')}>
              <Text style={{ color: '#10b981' }}>🎓 Class</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.quickButton, { borderColor: '#9333ea' }]} onPress={() => Alert.alert('Add meeting')}>
              <Text style={{ color: '#9333ea' }}>👥 Meeting</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Bottom Navigation */}
      <BottomNavigation userRole="admin" activeTab="calendar" />
    </View>
  );
};

export default ManageCalendar

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18 },
  addButton: { flexDirection: 'row', backgroundColor: '#ff6600', padding: 8, borderRadius: 6 },
  addButtonText: { color: '#fff', marginLeft: 6 },
  content: { padding: 16 },
  card: { padding: 12, borderRadius: 8, marginBottom: 12 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  eventIcon: { fontSize: 18, marginRight: 8 },
  eventTitle: { fontSize: 16, color: '#003366' },
  eventMeta: { fontSize: 12, color: '#555', marginTop: 2 },
  actions: { flexDirection: 'row', marginTop: 10 },
  editButton: { marginRight: 10, padding: 6, borderWidth: 1, borderColor: '#003366', borderRadius: 6 },
  deleteButton: { padding: 6, borderWidth: 1, borderColor: '#c00', borderRadius: 6 },
  quickAdd: { marginTop: 20 },
  quickAddTitle: { fontSize: 16, color: '#003366', marginBottom: 10 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  quickButton: { borderWidth: 1, borderRadius: 6, padding: 10, marginRight: 10, marginBottom: 10 },
});
