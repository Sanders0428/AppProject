import { Feather } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext, useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { mockSubmissions, Submission } from '../../src/constants/mockData';
import { AppContext } from '../../src/context/AppContext';
import {
  getDaysLate,
  getInitials,
  getStatusColor,
  getStatusIcon
} from '../../src/utils/submissionHelpers';

const ViewSubmissions: React.FC = () => {
  const context = useContext(AppContext);
  const router = useRouter();

  const [filterStatus, setFilterStatus] = useState<
    'all' | 'pending' | 'reviewed' | 'late'
  >('all');

  const handleBack = () => {
    router.push('../app/admin/dashboard');
  };

  const handleDownloadFile = (submissionId: string, fileName: string) => {
    Alert.alert('Download', `Download ${fileName} from submission ${submissionId}`);
  };

  const handleViewSubmission = (submissionId: string) => {
    Alert.alert('View', `View detailed submission: ${submissionId}`);
  };

  const handleMarkReviewed = (submissionId: string) => {
    Alert.alert('Reviewed', `Marked submission ${submissionId} as reviewed`);
  };

  const filteredSubmissions = mockSubmissions.filter(
    (sub) => filterStatus === 'all' || sub.status === filterStatus
  );

  const sortedSubmissions = filteredSubmissions
    .slice()
    .sort((a, b) => b.submittedDate.getTime() - a.submittedDate.getTime());

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Feather name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Review Submissions</Text>
      </View>

      {/* Filters */}
      <ScrollView
        horizontal
        style={styles.filterRow}
        contentContainerStyle={{ paddingHorizontal: 16 }}
        showsHorizontalScrollIndicator={false}
      >
        {(['all', 'pending', 'reviewed', 'late'] as const).map((status) => (
          <TouchableOpacity
            key={status}
            style={[
              styles.filterButton,
              filterStatus === status && styles.filterActive,
            ]}
            onPress={() => setFilterStatus(status)}
          >
            <Text
              style={[
                styles.filterText,
                filterStatus === status && styles.filterTextActive,
              ]}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)} (
              {status === 'all'
                ? mockSubmissions.length
                : mockSubmissions.filter((s) => s.status === status).length}
              )
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Content */}
      <ScrollView contentContainerStyle={styles.content}>
        {sortedSubmissions.map((sub: Submission) => (
          <View
            key={sub.id}
            style={[styles.card, { borderLeftColor: getStatusColor(sub.status) }]}
          >
            <View style={styles.cardHeader}>
              <View style={styles.avatar}>
                <Text style={styles.avatarText}>{getInitials(sub.studentName)}</Text>
              </View>
              <View style={styles.cardInfo}>
                <Text style={styles.assignment}>{sub.assignment}</Text>
                <Text style={styles.student}>{sub.studentName}</Text>
                <Text style={styles.course}>{sub.course}</Text>
              </View>
              <View style={styles.statusBlock}>
                <Text style={styles.statusIcon}>{getStatusIcon(sub.status)}</Text>
                <Text
                  style={[styles.statusBadge, { color: getStatusColor(sub.status) }]}
                >
                  {sub.status}
                </Text>
              </View>
            </View>

            <Text style={styles.meta}>
              📅 Submitted: {sub.submittedDate.toLocaleDateString()}
            </Text>
            <Text style={styles.meta}>
              📌 Due: {sub.dueDate.toLocaleDateString()}
            </Text>

            {sub.status === 'late' && (
              <Text style={styles.late}>
                ⚠️ {getDaysLate(sub.submittedDate, sub.dueDate)} days late
              </Text>
            )}

            {sub.grade != null && <Text style={styles.grade}>✅ Grade: {sub.grade}</Text>}

            {/* Files */}
            <View style={styles.fileList}>
              {sub.files.map((file, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.fileButton}
                  onPress={() => handleDownloadFile(sub.id, file)}
                >
                  <Feather name="download" size={12} color="#003366" />
                  <Text style={styles.fileText}>{file}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {/* Actions */}
            <View style={styles.actions}>
              <TouchableOpacity
                style={styles.viewButton}
                onPress={() => handleViewSubmission(sub.id)}
              >
                <Feather name="eye" size={14} color="#fff" />
                <Text style={styles.viewText}>View</Text>
              </TouchableOpacity>
              {sub.status === 'pending' && (
                <TouchableOpacity
                  style={styles.reviewButton}
                  onPress={() => handleMarkReviewed(sub.id)}
                >
                  <Feather name="check-circle" size={14} color="#fff" />
                  <Text style={styles.reviewText}>Mark Reviewed</Text>
                </TouchableOpacity>
              )}
            </View>
          </View>
        ))}

        {sortedSubmissions.length === 0 && (
          <View style={styles.empty}>
            <Feather name="clock" size={48} color="#ccc" />
            <Text style={styles.emptyText}>
              No submissions found for the selected filter.
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
};

export default ViewSubmissions;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#003366',
    padding: 16,
  },
  headerTitle: { color: '#fff', fontSize: 18, marginLeft: 10 },
  filterRow: { backgroundColor: '#fff', paddingVertical: 10 },
  filterButton: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 6,
    backgroundColor: '#fff',
    marginRight: 8,
  },
  filterActive: { backgroundColor: '#ff6600' },
  filterText: { fontSize: 12, color: '#003366' },
  filterTextActive: { color: '#fff' },
  content: { padding: 16 },
  card: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderLeftWidth: 4,
  },
  cardHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 6 },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#ff6600',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: { color: '#fff', fontWeight: 'bold' },
  cardInfo: { flex: 1, marginLeft: 10 },
  assignment: { fontSize: 16, color: '#003366' },
  student: { fontSize: 14, color: '#555' },
  course: { fontSize: 12, color: '#999' },
  statusBlock: { alignItems: 'center' },
  statusIcon: { fontSize: 18 },
  statusBadge: { fontSize: 12, marginTop: 2 },
  meta: { fontSize: 12, color: '#666', marginBottom: 2 },
  late: { fontSize: 12, color: '#c00', marginBottom: 4 },
  grade: { fontSize: 12, color: '#10b981', marginBottom: 4 },
  fileList: { flexDirection: 'row', flexWrap: 'wrap', marginBottom: 10 },
  fileButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e5e7eb',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    marginRight: 6,
    marginBottom: 6,
  },
  fileText: { fontSize: 12, marginLeft: 4, color: '#003366' },
  actions: { flexDirection: 'row', justifyContent: 'flex-start' },
  viewButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#003366',
    padding: 10,
    borderRadius: 6,
    marginRight: 10,
  },
  viewText: { color: '#fff', marginLeft: 6 },
  reviewButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#ff6600',
    padding: 10,
    borderRadius: 6,
  },
  reviewText: { color: '#fff', marginLeft: 6 },
  empty: { alignItems: 'center', marginTop: 40 },
  emptyText: { fontSize: 14, color: '#666', marginTop: 12 },
});
