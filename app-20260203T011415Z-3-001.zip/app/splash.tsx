import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React from 'react';
import { ActivityIndicator, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

const SplashScreen = () => {
  const router = useRouter();

  const handleTap = () => {
    router.push('/login');
     // ✅ Correct route
  };

  return (
    <TouchableOpacity style={styles.container} onPress={handleTap} activeOpacity={0.8}>
      <View style={styles.content}>
        <View style={styles.logoCircle}>
          <Icon name="book" size={48} color="#fff" />
        </View>

        <View style={styles.textBlock}>
          <Text style={styles.title}>Happy Training Academy</Text>
          <Text style={styles.subtitle}>
            Empowering South African learners through quality education and coaching
          </Text>
        </View>

        <ActivityIndicator size="large" color="#ff6600" style={styles.spinner} />
        <Text style={styles.tapText}>Tap to continue</Text>
      </View>
    </TouchableOpacity>
  );
};

export default SplashScreen;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#003366', justifyContent: 'center', alignItems: 'center' },
  content: { alignItems: 'center', paddingHorizontal: 20 },
  logoCircle: { backgroundColor: '#ff6600', padding: 20, borderRadius: 100, marginBottom: 30 },
  textBlock: { alignItems: 'center', marginBottom: 40 },
  title: { fontSize: 28, color: '#fff', fontWeight: 'bold', textAlign: 'center' },
  subtitle: { fontSize: 14, color: '#ccc', textAlign: 'center', marginTop: 10 },
  spinner: { marginBottom: 30 },
  tapText: { fontSize: 12, color: '#aaa' },
});
