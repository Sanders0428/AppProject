// app/(learner)/complete-courses.tsx
import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext } from 'react';
import { Alert, FlatList, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { AppContext } from '../src/context/AppContext';

export default function CompleteCourses() {
  const router = useRouter();
  const context = useContext(AppContext);

  if (!context) {
    return (
      <View style={styles.centered}>
        <Text>App context not available</Text>
      </View>
    );
  }

  const completed = context.user?.completedCourses || [];
  const certificates = context.user?.certificates || [];

  const handleBack = () => router.push('//dashboard');

  const handleViewCertificate = (index: number, courseTitle?: string) => {
    // For now show an alert. Replace with real viewer / PDF flow when available.
    const cert = certificates[index] || `Certificate for ${courseTitle || 'course'}`;
    Alert.alert('Certificate', cert);
  };

  const renderItem = ({ item, index }: { item: any; index: number }) => (
    <View style={styles.card}>
      <View style={styles.cardRow}>
        <View style={styles.cardText}>
          <Text style={styles.title}>{item.title}</Text>
          <Text style={styles.subtitle}>{item.instructor || 'Happy Training'}</Text>
        </View>
        <View style={styles.actions}>
          <Text style={styles.progress}>Completed</Text>
          <TouchableOpacity
            style={styles.certButton}
            onPress={() => handleViewCertificate(index, item.title)}
          >
            <Icon name="award" size={16} color="#fff" />
            <Text style={styles.certText}>View Certificate</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-left" size={22} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Completed Courses</Text>
        <View style={{ width: 22 }} />
      </View>

      <View style={styles.content}>
        {completed.length === 0 ? (
          <View style={styles.empty}>
            <Text style={styles.emptyTitle}>No completed courses yet</Text>
            <Text style={styles.emptySubtitle}>Complete a course to earn certificates</Text>
            <TouchableOpacity style={styles.cta} onPress={() => router.push('//courses')}>
              <Text style={styles.ctaText}>Browse Courses</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <Text style={styles.count}>You have completed <Text style={{ fontWeight: '700' }}>{completed.length}</Text> course{completed.length > 1 ? 's' : ''}</Text>
            <FlatList
              data={completed}
              keyExtractor={(c) => c.id}
              renderItem={renderItem}
              contentContainerStyle={{ paddingBottom: 24 }}
              showsVerticalScrollIndicator={false}
            />
          </>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18 },
  content: { padding: 16, flex: 1 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },

  empty: { alignItems: 'center', marginTop: 60 },
  emptyTitle: { fontSize: 18, color: '#003366', marginBottom: 8 },
  emptySubtitle: { fontSize: 14, color: '#666', marginBottom: 16, textAlign: 'center' },
  cta: { backgroundColor: '#ff6600', paddingHorizontal: 16, paddingVertical: 10, borderRadius: 8 },
  ctaText: { color: '#fff', fontWeight: '700' },

  count: { fontSize: 14, color: '#666', marginBottom: 12 },

  card: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 12 },
  cardRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardText: { flex: 1, marginRight: 12 },
  title: { fontSize: 16, color: '#003366' },
  subtitle: { fontSize: 12, color: '#666', marginTop: 4 },

  actions: { alignItems: 'flex-end' },
  progress: { fontSize: 12, color: '#10b981', marginBottom: 8 },

  certButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#003366', paddingHorizontal: 10, paddingVertical: 6, borderRadius: 6 },
  certText: { color: '#fff', marginLeft: 8, fontSize: 13 },
});
