// app/register.tsx
import { useRouter } from 'expo-router';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import React, { useContext, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { auth } from '../firebase';
import { AppContext } from '../src/context/AppContext';

export default function RegistrationScreen() {
  const context = useContext(AppContext);
  const router = useRouter();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const emailRef = useRef<TextInput | null>(null);
  const locationRef = useRef<TextInput | null>(null);
  const passwordRef = useRef<TextInput | null>(null);

  const handleRegister = async () => {
    setError('');

    if (!fullName.trim() || !email.trim() || !location.trim() || !password || !confirmPassword) {
      setError('Please fill in all fields');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);

      // Build user object compatible with AppContext (initialize arrays)
      const newUser = {
        id: userCredential.user.uid,
        fullName: fullName.trim(),
        email: email.trim(),
        location: location.trim(),
        role: 'learner' as const,
        enrolledCourses: [],
        completedCourses: [],
        certificates: [],
      };

      // Update context and route into app
      context?.setUser?.(newUser);
      context?.setUserRole?.('learner');
      context?.setCurrentScreen?.('learner-dashboard');

      // navigate to grouped learner dashboard route
      router.replace('/dashboard');
    } catch (err: any) {
      const msg = err?.message || 'Registration failed';
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.wrap}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0}
    >
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <View style={styles.center}>
          <View style={styles.brand}>
            <Image source={require('../assets/images/splash-icon.png')} style={styles.logo} resizeMode="contain" />
            <Text style={styles.brandTitle}>Happy Training Academy</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.title}>Create an account</Text>
            <Text style={styles.subtitle}>Join Happy Training Academy and start learning</Text>

            <TextInput
              style={styles.input}
              placeholder="Full name"
              placeholderTextColor="#9aa3b2"
              value={fullName}
              onChangeText={setFullName}
              returnKeyType="next"
              onSubmitEditing={() => emailRef.current?.focus()}
              editable={!loading}
            />

            <TextInput
              ref={emailRef}
              style={styles.input}
              placeholder="Email address"
              placeholderTextColor="#9aa3b2"
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
              returnKeyType="next"
              onSubmitEditing={() => locationRef.current?.focus()}
              editable={!loading}
            />

            <TextInput
              ref={locationRef}
              style={styles.input}
              placeholder="Location"
              placeholderTextColor="#9aa3b2"
              value={location}
              onChangeText={setLocation}
              returnKeyType="next"
              onSubmitEditing={() => passwordRef.current?.focus()}
              editable={!loading}
            />

            <TextInput
              ref={passwordRef}
              style={styles.input}
              placeholder="Password"
              placeholderTextColor="#9aa3b2"
              secureTextEntry
              value={password}
              onChangeText={setPassword}
              returnKeyType="next"
              editable={!loading}
            />

            <TextInput
              style={styles.input}
              placeholder="Confirm password"
              placeholderTextColor="#9aa3b2"
              secureTextEntry
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              returnKeyType="done"
              editable={!loading}
            />

            {error ? <Text style={styles.error}>{error}</Text> : null}

            <TouchableOpacity
              style={[styles.button, loading && styles.buttonDisabled]}
              onPress={handleRegister}
              disabled={loading}
              accessibilityRole="button"
            >
              {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Create account</Text>}
            </TouchableOpacity>

            <TouchableOpacity onPress={() => router.replace('/login')} style={styles.linkRow}>
              <Text style={styles.linkText}>Already have an account? Sign in</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#f2f2f2' },
  scroll: { flexGrow: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },

  brand: { alignItems: 'center', marginBottom: 18 },
  logo: { width: 84, height: 84, marginBottom: 8 },
  brandTitle: { color: '#003366', fontSize: 18, fontWeight: '700' },

  card: {
    width: '100%',
    maxWidth: 520,
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 6,
  },
  title: { fontSize: 20, color: '#003366', fontWeight: '700', marginBottom: 6, textAlign: 'center' },
  subtitle: { color: '#667182', fontSize: 13, textAlign: 'center', marginBottom: 14 },

  input: {
    backgroundColor: '#f7f9fb',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e6eef6',
    color: '#102030',
    marginBottom: 12,
    fontSize: 15,
  },

  button: {
    backgroundColor: '#ff6600',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: { opacity: 0.6, backgroundColor: '#ff8c4d' },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },

  linkRow: { marginTop: 12, alignItems: 'center' },
  linkText: { color: '#003366', fontWeight: '600' },

  error: { color: '#b00020', textAlign: 'center', marginTop: 6 },
});
