// src/screens/ProfileScreen.tsx
import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext, useMemo, useState } from 'react';
import {
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { AppContext } from '../src/context/AppContext';

const ProfileScreen = () => {
  const context = useContext(AppContext);
  const router = useRouter();
  const user = context?.user;
  const [isEditing, setIsEditing] = useState(false);

  // Local editable form state
  const [fullName, setFullName] = useState(user?.fullName ?? '');
  const [location, setLocation] = useState(user?.location ?? '');
  const [email] = useState(user?.email ?? '');

  if (!user) {
    // Optionally route to login if no user
    // router.replace('/login');
    return null;
  }

  const handleLogout = () => {
    // clear user in context and navigate to login
    context?.setUser?.(null);
   context?.setUserRole?.(null);
    context?.setCurrentScreen?.('login');
    router.replace('/login');
  };

  const toggleEdit = () => {
    if (isEditing) {
      // save action: validate and update context
      if (!fullName.trim()) {
        Alert.alert('Validation', 'Full name cannot be empty');
        return;
      }
      const updated = { ...user, fullName: fullName.trim(), location: location.trim() };
      context?.setUser?.(updated);
      setIsEditing(false);
      Alert.alert('Profile', 'Profile updated');
    } else {
      setIsEditing(true);
    }
  };

  const getInitials = (name: string) =>
    name
      .split(' ')
      .map((word) => word.charAt(0))
      .join('')
      .slice(0, 3)
      .toUpperCase();

  type Stat = { label: string; value: string; icon: keyof typeof Icon.glyphMap; color: string };

  const learnerStats: Stat[] = useMemo(
    () => [
      { label: 'Courses Enrolled', value: String(user.enrolledCourses?.length ?? 0), icon: 'book', color: '#3b82f6' },
      { label: 'Certificates', value: String(user.certificates?.length ?? 0), icon: 'award' as any, color: '#facc15' },
      { label: 'Hours Completed', value: '47', icon: 'calendar', color: '#10b981' },
    ],
    [user]
  );

  const adminStats: Stat[] = [
    { label: 'Total Courses', value: '12', icon: 'book', color: '#3b82f6' },
    { label: 'Total Learners', value: '248', icon: 'user', color: '#10b981' },
    { label: 'Pending Reviews', value: '15', icon: 'edit', color: '#f97316' },
  ];

  const stats = user.role === 'admin' ? adminStats : learnerStats;

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Profile</Text>
        <TouchableOpacity onPress={toggleEdit} accessibilityRole="button" accessibilityLabel={isEditing ? 'Save profile' : 'Edit profile'}>
          <Icon name={isEditing ? 'check' : 'edit'} size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        {/* Profile Info Card */}
        <View style={styles.card}>
          <View style={styles.profileRow}>
            <View style={styles.avatar}>
              <Text style={styles.avatarText}>{getInitials(user.fullName || 'U')}</Text>
            </View>

            <View style={styles.profileInfo}>
              {isEditing ? (
                <>
                  <TextInput
                    value={fullName}
                    onChangeText={setFullName}
                    style={styles.input}
                    placeholder="Full name"
                    placeholderTextColor="#9aa3b2"
                  />
                  <TextInput
                    value={location}
                    onChangeText={setLocation}
                    style={styles.input}
                    placeholder="Location"
                    placeholderTextColor="#9aa3b2"
                  />
                </>
              ) : (
                <>
                  <Text style={styles.name}>{user.fullName}</Text>
                  <Text style={styles.role}>{user.role}</Text>
                  <Text style={styles.location}>📍 {user.location || '—'}</Text>
                </>
              )}
            </View>
          </View>

          <View style={styles.rowMeta}>
            <Text style={styles.email}>📧 {email}</Text>
            <Text style={styles.meta}>👤 Member since March 2024</Text>
          </View>
        </View>

        {/* Statistics Card */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Statistics</Text>
          <View style={styles.statsRow}>
            {stats.map((stat, idx) => (
              <View key={idx} style={styles.statItem}>
                <Icon name={stat.icon as any} size={26} color={stat.color} />
                <Text style={styles.statValue}>{stat.value}</Text>
                <Text style={styles.statLabel}>{stat.label}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* Account Actions Card */}
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Account</Text>

          <TouchableOpacity
            style={styles.actionItem}
            onPress={() => router.push('../settings-screen')}
            accessibilityRole="button"
          >
            <Icon name="settings" size={18} color="#666" />
            <Text style={styles.actionText}>Account Settings</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionItem}
            onPress={() => router.push('../certificates-screen')}
            accessibilityRole="button"
          >
            <Icon name="award" size={18} color="#666" />
            <Text style={styles.actionText}>Certificates & Achievements</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.actionItem}
            onPress={() => router.push('../learning-history-screen')}
            accessibilityRole="button"
          >
            <Icon name="book" size={18} color="#666" />
            <Text style={styles.actionText}>Learning History</Text>
          </TouchableOpacity>
        </View>

        {/* Logout */}
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout} accessibilityRole="button">
          <Icon name="log-out" size={16} color="#c00" />
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#003366',
    paddingHorizontal: 16,
    paddingVertical: 14,
    alignItems: 'center',
  },
  headerTitle: { color: '#fff', fontSize: 18, fontWeight: '700' },
  content: { padding: 16, paddingBottom: 90 },

  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 10,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOpacity: 0.03,
    shadowRadius: 8,
    elevation: 2,
  },

  profileRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  avatar: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: '#ff6600',
    justifyContent: 'center',
    alignItems: 'center',
  },
  avatarText: { color: '#fff', fontSize: 24, fontWeight: '700' },
  profileInfo: { marginLeft: 14, flex: 1 },
  name: { fontSize: 18, color: '#003366', fontWeight: '700' },
  role: { fontSize: 14, color: '#666', textTransform: 'capitalize' },
  location: { fontSize: 13, color: '#666', marginTop: 4 },

  rowMeta: { marginTop: 8 },
  email: { fontSize: 14, color: '#333', marginBottom: 4 },
  meta: { fontSize: 12, color: '#666' },

  sectionTitle: { fontSize: 16, color: '#003366', marginBottom: 10, fontWeight: '600' },

  statsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  statItem: { alignItems: 'center', flex: 1, paddingVertical: 8 },
  statValue: { fontSize: 18, color: '#003366', marginTop: 6, fontWeight: '700' },
  statLabel: { fontSize: 12, color: '#666', marginTop: 4, textAlign: 'center' },

  actionItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12 },
  actionText: { marginLeft: 12, fontSize: 15, color: '#333' },

  logoutButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#c00',
    padding: 12,
    borderRadius: 8,
    backgroundColor: '#fff',
  },
  logoutText: { color: '#c00', marginLeft: 8, fontSize: 14, fontWeight: '600' },

  input: {
    backgroundColor: '#f7f9fb',
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e6eef6',
    color: '#102030',
    marginBottom: 8,
    fontSize: 15,
  },
});
