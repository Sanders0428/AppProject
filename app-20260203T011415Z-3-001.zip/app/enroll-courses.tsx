// app/(learner)/enroll-courses.tsx
import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext, useMemo } from 'react';
import {
    Alert,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from 'react-native';
import BottomNavigation from '../src/components/BottomNavigation';
import { AppContext } from '../src/context/AppContext';

const COURSES = [
  { id: 'first-aid', title: 'First Aid Training (Level 1–3)', description: 'Accredited first responder training for workplace emergencies.', mode: 'instructor-led', duration: '1–3 days', instructor: 'Happy Training' },
  { id: 'fire-fighting', title: 'Basic Fire Fighting', description: 'Learn to prevent and respond to workplace fire hazards.', mode: 'instructor-led', duration: '1 day', instructor: 'Happy Training' },
  { id: 'she-rep', title: 'SHE Rep (Safety Health Environment)', description: 'Become a certified workplace safety representative.', mode: 'instructor-led', duration: '5 days', instructor: 'Happy Training' },
  { id: 'forklift', title: 'Forklift Operator', description: 'Accredited forklift operation and safety training.', mode: 'practical', duration: '5 days', instructor: 'Happy Training' },
  { id: 'working-at-heights', title: 'Working at Heights', description: 'Safe practices and rescue training for elevated work.', mode: 'instructor-led', duration: '3 days', instructor: 'Happy Training' },
  { id: 'risk-assessment', title: 'Risk Assessment (HIRAC)', description: 'Conduct HIRAC risk assessments for workplace safety.', mode: 'instructor-led', duration: '1 day', instructor: 'Happy Training' },
];

export default function EnrollCourses() {
  const router = useRouter();
  const context = useContext(AppContext);

  // defensive checks
  if (!context) {
    return (
      <View style={styles.centered}>
        <Text>App context not available</Text>
      </View>
    );
  }

  const enrolledIds = useMemo(
    () => new Set(context.user?.enrolledCourses?.map(c => c.id) || []),
    [context.user],
  );

  const handleOpenDetails = (course: typeof COURSES[number]) => {
    context.setSelectedCourse?.({
      id: course.id,
      title: course.title,
      description: course.description,
      image: '',
      mode: course.mode,
      instructor: course.instructor,
      duration: course.duration,
      progress: context.user?.enrolledCourses?.find(c => c.id === course.id)?.progress ?? 0,
      enrolled: enrolledIds.has(course.id),
    });
    router.push('//course-details');
  };

  const handleEnroll = (course: typeof COURSES[number]) => {
    if (!context.user) {
      Alert.alert('Not signed in', 'Please sign in or register to enroll in courses.');
      return;
    }

    // prepare CourseType shape used by context
    const courseToEnroll = {
      id: course.id,
      title: course.title,
      description: course.description,
      image: '',
      mode: course.mode,
      instructor: course.instructor,
      duration: course.duration,
      progress: 0,
      enrolled: true,
    };

    context.enrollCourse?.(courseToEnroll as any);
    Alert.alert('Enrolled', `You have been enrolled in "${course.title}".`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Available Courses</Text>
        <Text style={styles.headerSubtitle}>Browse courses and enroll</Text>
      </View>

      <ScrollView contentContainerStyle={[styles.content, { paddingBottom: 90 }]}>
        {COURSES.map(course => {
          const isEnrolled = enrolledIds.has(course.id);
          return (
            <View key={course.id} style={[styles.card, isEnrolled ? styles.cardEnrolled : styles.cardAvailable]}>
              <TouchableOpacity style={styles.cardRow} onPress={() => handleOpenDetails(course)}>
                <Icon name="book-open" size={20} color="#003366" />
                <Text style={styles.cardTitle}>{course.title}</Text>
                {isEnrolled && <Icon name="check-circle" size={18} color="#10b981" />}
              </TouchableOpacity>

              <Text style={styles.cardMeta}>{course.duration} • {course.mode}</Text>
              <Text style={styles.cardDescription}>{course.description}</Text>

              <View style={styles.actionsRow}>
                <TouchableOpacity style={styles.detailsButton} onPress={() => handleOpenDetails(course)}>
                  <Text style={styles.detailsText}>Details</Text>
                </TouchableOpacity>

                {!isEnrolled ? (
                  <TouchableOpacity style={styles.enrollButton} onPress={() => handleEnroll(course)}>
                    <Text style={styles.enrollText}>Enroll</Text>
                  </TouchableOpacity>
                ) : (
                  <TouchableOpacity style={styles.goButton} onPress={() => router.push('//dashboard')}>
                    <Text style={styles.goText}>Go to Dashboard</Text>
                  </TouchableOpacity>
                )}
              

              </View>
            </View>
          );
        })}
      </ScrollView>
      <BottomNavigation userRole={context.user?.role} activeTab="courses" />

    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18 },
  headerSubtitle: { color: '#ccc', fontSize: 14, marginTop: 4 },
  content: { padding: 16 },
  card: { backgroundColor: '#fff', padding: 14, borderRadius: 8, marginBottom: 12 },
  cardRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardTitle: { fontSize: 15, color: '#003366', flex: 1, marginLeft: 10 },
  cardMeta: { fontSize: 12, color: '#666', marginTop: 8 },
  cardDescription: { fontSize: 13, color: '#444', marginTop: 6 },
  actionsRow: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 10, gap: 8 },
  detailsButton: { paddingVertical: 6, paddingHorizontal: 10, borderRadius: 6, borderWidth: 1, borderColor: '#003366', marginRight: 8 },
  detailsText: { color: '#003366', fontSize: 13 },
  enrollButton: { backgroundColor: '#ff6600', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6 },
  enrollText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  goButton: { backgroundColor: '#10b981', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6 },
  goText: { color: '#fff', fontSize: 13, fontWeight: '600' },
  cardEnrolled: { borderLeftWidth: 4, borderLeftColor: '#10b981' },
  cardAvailable: { borderLeftWidth: 4, borderLeftColor: '#ff6600' },
});
