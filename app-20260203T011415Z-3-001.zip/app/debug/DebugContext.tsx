// app/debug/DebugContext.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAuth, signOut } from 'firebase/auth';
import React, { useContext, useState } from 'react';
import { Alert, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { AppContext } from '../../src/context/AppContext';
import { verifyWithBackend } from '../../src/lib/authService';

export default function DebugContextScreen() {
  const ctx = useContext(AppContext);
  const [busy, setBusy] = useState(false);
  const [verifyResult, setVerifyResult] = useState<string | null>(null);

  const handleVerify = async () => {
    setBusy(true);
    setVerifyResult(null);
    try {
      const res = await verifyWithBackend();
      setVerifyResult(res ? JSON.stringify(res, null, 2) : 'null (verification failed)');
    } catch (err: any) {
      setVerifyResult(`error: ${err?.message ?? String(err)}`);
    } finally {
      setBusy(false);
    }
  };

  const handleRefreshToken = async () => {
    setBusy(true);
    try {
      const auth = getAuth();
      if (!auth.currentUser) {
        Alert.alert('No Firebase user', 'Sign in first');
        return;
      }
      await auth.currentUser.getIdToken(true);
      Alert.alert('Token refreshed', 'Forced token refresh completed');
    } catch (err: any) {
      Alert.alert('Refresh failed', err?.message ?? String(err));
    } finally {
      setBusy(false);
    }
  };

  const handleSignOut = async () => {
    try {
      const auth = getAuth();
      await signOut(auth);
      Alert.alert('Signed out', 'Firebase sign out completed');
    } catch (err: any) {
      Alert.alert('Sign out failed', err?.message ?? String(err));
    }
  };

  const handleClearEnrollments = async () => {
    try {
      await AsyncStorage.removeItem('@happytraining:enrolled_course_ids');
      Alert.alert('Cleared', 'Persisted enrolled course ids removed');
    } catch (err: any) {
      Alert.alert('Clear failed', err?.message ?? String(err));
    }
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>AppContext Debug</Text>

        <View style={styles.section}>
          <Text style={styles.label}>currentScreen</Text>
          <Text style={styles.value}>{ctx?.currentScreen ?? 'null'}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>userRole</Text>
          <Text style={styles.value}>{ctx?.userRole ?? 'null'}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>user (context)</Text>
          <Text style={styles.mono}>{ctx?.user ? JSON.stringify(ctx.user, null, 2) : 'null'}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>selectedCourse</Text>
          <Text style={styles.value}>{ctx?.selectedCourse ? ctx.selectedCourse.title : 'null'}</Text>
        </View>

        <View style={styles.actionsRow}>
          <Pressable style={styles.button} onPress={handleVerify} disabled={busy} accessibilityRole="button">
            <Text style={styles.buttonText}>{busy ? 'Verifying...' : 'Verify with backend'}</Text>
          </Pressable>

          <Pressable style={styles.button} onPress={handleRefreshToken} disabled={busy} accessibilityRole="button">
            <Text style={styles.buttonText}>Refresh token</Text>
          </Pressable>
        </View>

        <View style={styles.actionsRow}>
          <Pressable style={styles.dangerBtn} onPress={handleSignOut} accessibilityRole="button">
            <Text style={styles.dangerText}>Sign out (Firebase)</Text>
          </Pressable>

          <Pressable style={styles.smallBtn} onPress={handleClearEnrollments} accessibilityRole="button">
            <Text style={styles.smallText}>Clear enrollments</Text>
          </Pressable>
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>Last verify result</Text>
          <Text style={styles.mono}>{verifyResult ?? 'Not run'}</Text>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f6f7fb' },
  container: { padding: 16 },
  heading: { fontSize: 20, fontWeight: '700', color: '#003366', marginBottom: 12 },
  section: { marginBottom: 12 },
  label: { fontSize: 13, color: '#666', marginBottom: 6 },
  value: { fontSize: 14, color: '#222' },
  mono: { fontFamily: 'monospace', fontSize: 12, color: '#111', backgroundColor: '#fff', padding: 8, borderRadius: 8 },
  actionsRow: { flexDirection: 'row', gap: 8, marginVertical: 8 },
  button: { flex: 1, backgroundColor: '#003366', paddingVertical: 10, borderRadius: 8, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: '600' },
  dangerBtn: { flex: 1, backgroundColor: '#fff', borderWidth: 1, borderColor: '#c33', paddingVertical: 10, borderRadius: 8, alignItems: 'center' },
  dangerText: { color: '#c33', fontWeight: '700' },
  smallBtn: { paddingHorizontal: 12, paddingVertical: 10, backgroundColor: '#fff', borderRadius: 8, borderWidth: 1, borderColor: '#ccc' },
  smallText: { color: '#333', fontWeight: '600' },
});
