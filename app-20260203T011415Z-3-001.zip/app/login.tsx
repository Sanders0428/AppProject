// app/login.tsx
import { useRouter } from 'expo-router';
import { signInWithEmailAndPassword } from 'firebase/auth';
import React, { useContext, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { auth } from '../firebase';
import { AppContext } from '../src/context/AppContext';

export default function LoginScreen() {
  const context = useContext(AppContext);
  const router = useRouter();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const passwordRef = useRef<TextInput | null>(null);

  const onSubmit = async () => {
    if (!email.trim() || !password) {
      setError('Please enter email and password');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
      const role: 'admin' | 'learner' = email.includes('admin') ? 'admin' : 'learner';

      const newUser = {
        id: userCredential.user.uid,
        fullName: role === 'admin' ? 'Admin User' : 'Learner User',
        email: email.trim(),
        location: '',
        role,
        enrolledCourses: [],
        completedCourses: [],
        certificates: [],
      };

      context?.setUser?.(newUser);
      context?.setUserRole?.(role);
      context?.setCurrentScreen?.(role === 'admin' ? 'admin-dashboard' : 'learner-dashboard');

      // Corrected routes: use grouped expo-router routes for learner/admin
      if (role === 'admin') {
        router.replace('/admin/dashboard');
      } else {
        router.replace('/dashboard');
      }
    } catch (err: any) {
      setError('Invalid credentials. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: '#f2f2f2' }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 0}
    >
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
        <View style={styles.center}>
          <View style={styles.brand}>
            <Image source={require('../assets/images/splash-icon.png')} style={styles.logo} resizeMode="contain" />
            <Text style={styles.brandTitle}>Happy Training Academy</Text>
          </View>

          <View style={styles.card}>
            <Text style={styles.title}>Welcome back</Text>
            <Text style={styles.subtitle}>Sign in to continue learning</Text>

            <TextInput
              style={styles.input}
              placeholder="Email address"
              placeholderTextColor="#9aa3b2"
              keyboardType="email-address"
              autoCapitalize="none"
              value={email}
              onChangeText={setEmail}
              returnKeyType="next"
              onSubmitEditing={() => passwordRef.current?.focus()}
              editable={!loading}
            />

            <View style={styles.passwordRow}>
              <TextInput
                ref={passwordRef}
                style={[styles.input, { flex: 1 }]}
                placeholder="Password"
                placeholderTextColor="#9aa3b2"
                secureTextEntry={!showPassword}
                value={password}
                onChangeText={setPassword}
                returnKeyType="done"
                editable={!loading}
              />
              <TouchableOpacity onPress={() => setShowPassword(s => !s)} style={styles.showBtn}>
                <Text style={styles.showText}>{showPassword ? 'Hide' : 'Show'}</Text>
              </TouchableOpacity>
            </View>

            {error ? <Text style={styles.error}>{error}</Text> : null}

            <TouchableOpacity
              style={[styles.button, (!email || !password || loading) && styles.buttonDisabled]}
              onPress={onSubmit}
              disabled={!email || !password || loading}
              accessibilityRole="button"
            >
              {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Sign in</Text>}
            </TouchableOpacity>

            <TouchableOpacity onPress={() => router.push('/register')} style={styles.linkRow}>
              <Text style={styles.linkText}>Don't have an account? Create one</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  scroll: { flexGrow: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
  brand: { alignItems: 'center', marginBottom: 18 },
  logo: { width: 84, height: 84, marginBottom: 8 },
  brandTitle: { color: '#003366', fontSize: 18, fontWeight: '700' },

  card: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: '#fff',
    borderRadius: 14,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 6,
  },
  title: { fontSize: 20, color: '#003366', fontWeight: '700', marginBottom: 6, textAlign: 'center' },
  subtitle: { color: '#667182', fontSize: 13, textAlign: 'center', marginBottom: 16 },

  input: {
    backgroundColor: '#f7f9fb',
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#e6eef6',
    color: '#102030',
    marginBottom: 12,
    fontSize: 15,
  },
  passwordRow: { flexDirection: 'row', alignItems: 'center' },
  showBtn: { marginLeft: 10 },
  showText: { color: '#003366', fontWeight: '600' },

  button: {
    backgroundColor: '#ff6600',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 8,
  },
  buttonDisabled: { opacity: 0.6, backgroundColor: '#ff8c4d' },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 16 },

  linkRow: { marginTop: 12, alignItems: 'center' },
  linkText: { color: '#003366', fontWeight: '600' },

  error: { color: '#b00020', textAlign: 'center', marginTop: 6 },
});
