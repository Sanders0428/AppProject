// app/_layout.tsx or app/app.tsx
import React, { useContext } from 'react';
import { View } from 'react-native';

import CalendarScreen from '../app/calendar';
import CourseDetails from '../app/course-details';
import LearnerDashboard from '../app/dashboard';
import LoginScreen from '../app/login';
import ProfileScreen from '../app/profile';
import RegistrationScreen from '../app/register';
import SplashScreen from '../app/splash';
import UploadAssessment from '../app/upload-assessment';

import AdminDashboard from '../app/admin/dashboard';
import ManageCalendar from '../app/admin/manage-calendar';
import ManageCourses from '../app/admin/manage-courses';
import ViewLearners from '../app/admin/view-learners';
import ViewSubmissions from '../app/admin/view-submissions';

import { AppContext, AppProvider } from '../src/context/AppContext';

/**
 * InnerRenderer reads the currentScreen from AppContext and returns the appropriate screen.
 * Keeping the same switch logic you had previously, but driven by shared context.
 */
const InnerRenderer = () => {
  const ctx = useContext(AppContext);

  // defensive: if context is not ready yet, show splash
  const currentScreen = ctx?.currentScreen ?? 'splash';

  switch (currentScreen) {
    // Shared
    case 'splash':
      return <SplashScreen />;
    case 'login':
      return <LoginScreen />;
    case 'register':
      return <RegistrationScreen />;

    // Learner
    case 'learner-dashboard':
      return <LearnerDashboard />;
    case 'course-details':
      return <CourseDetails />;
    case 'calendar':
      return <CalendarScreen />;
    case 'upload-assessment':
      return <UploadAssessment />;
    case 'profile':
      return <ProfileScreen />;

    // Admin
    case 'admin-dashboard':
      return <AdminDashboard />;
    case 'manage-courses':
      return <ManageCourses />;
    case 'manage-calendar':
      return <ManageCalendar />;
    case 'view-learners':
      return <ViewLearners />;
    case 'view-submissions':
      return <ViewSubmissions />;

    default:
      return <SplashScreen />;
  }
};

export default function App() {
  return (
    <AppProvider>
      <View style={{ flex: 1 }}>
        <InnerRenderer />
      </View>
    </AppProvider>
  );
}
