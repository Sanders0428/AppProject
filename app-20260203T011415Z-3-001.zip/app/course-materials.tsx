// app/(learner)/course-materials.tsx
import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext, useMemo, useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { AppContext } from '../src/context/AppContext';

type Material = {
  id: string;
  name: string;
  type: 'video' | 'pdf' | 'document' | 'image';
  size?: string;
  duration?: string;
  completed?: boolean;
};

const MOCK_MATERIALS: Material[] = [
  { id: '1', name: 'Course Introduction.mp4', type: 'video', size: '45 MB', completed: true, duration: '12:30' },
  { id: '2', name: 'Module 1 - Getting Started.pdf', type: 'pdf', size: '2.1 MB', completed: true },
  { id: '3', name: 'Exercise Worksheet.pdf', type: 'pdf', size: '1.5 MB', completed: false },
  { id: '4', name: 'Case Study Examples.mp4', type: 'video', size: '78 MB', completed: false, duration: '25:45' },
  { id: '5', name: 'Reference Guide.pdf', type: 'document', size: '3.2 MB', completed: false },
  { id: '6', name: 'Infographic.png', type: 'image', size: '890 KB', completed: true },
  { id: '7', name: 'Final Project Template.pdf', type: 'pdf', size: '1.8 MB', completed: false },
];

export default function CourseMaterials() {
  const router = useRouter();
  const context = useContext(AppContext);

  // defensive
  if (!context) {
    return (
      <View style={styles.centered}>
        <Text>App context not available</Text>
      </View>
    );
  }

  const course = context.selectedCourse;
  if (!course) {
    return (
      <View style={styles.centered}>
        <Text>No course selected</Text>
      </View>
    );
  }

  // Local materials state so user can mark items complete in-session.
  const [materials, setMaterials] = useState<Material[]>(
    // if course.progress exists we could derive completed items; for now use mock completion flags
    MOCK_MATERIALS
  );

  const completedCount = useMemo(() => materials.filter(m => m.completed).length, [materials]);
  const progressPercentage = Math.round((completedCount / materials.length) * 100);

  // Update enrolled course progress in context when materials change
  const syncProgressToContext = (percent: number) => {
    if (!context.user) return;
    const enrolled = context.user.enrolledCourses || [];
    const idx = enrolled.findIndex(c => c.id === course.id);
    if (idx === -1) return;
    const updatedCourse = { ...enrolled[idx], progress: percent };
    const updatedEnrolled = [...enrolled];
    updatedEnrolled[idx] = updatedCourse;
    context.setUser?.({ ...context.user, enrolledCourses: updatedEnrolled });
  };

  // call sync on progress change
  React.useEffect(() => {
    syncProgressToContext(progressPercentage);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [progressPercentage]);

  const toggleComplete = (id: string) => {
    setMaterials(prev =>
      prev.map(m => (m.id === id ? { ...m, completed: !m.completed } : m))
    );
  };

  const handleBack = () => {
    router.back();
  };

  const handleView = (material: Material) => {
    // Replace with actual viewer / video player integration
    Alert.alert(material.name, `Open ${material.type}. (Mock)`);
  };

  const handleDownload = (material: Material) => {
    Alert.alert('Download', `Downloading ${material.name}... (Mock)`);
  };

  const handleFinalAssessment = () => {
    if (!context.user) {
      Alert.alert('Not signed in', 'Please log in to take the assessment.');
      return;
    }

    // Mark course complete via context helper (moves to completedCourses & issues certificate)
    context.completeCourse?.(course.id);
    Alert.alert('Assessment submitted', 'Course marked as complete. Certificate added.');
    // Go to completed courses or dashboard
    router.replace('//complete-courses');
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'video': return <Icon name="video" size={20} color="#ef4444" />;
      case 'pdf':
      case 'document': return <Icon name="file-text" size={20} color="#3b82f6" />;
      case 'image': return <Icon name="image" size={20} color="#10b981" />;
      default: return <Icon name="file" size={20} color="#666" />;
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>

        <View style={styles.headerText}>
          <Text style={styles.headerTitle}>Course Materials</Text>
          <Text style={styles.headerSubtitle} numberOfLines={1}>{course.title}</Text>
        </View>

        <View style={{ width: 24 }} />
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${progressPercentage}%` }]} />
          </View>
          <Text style={styles.progressText}>
            {completedCount} of {materials.length} materials completed ({progressPercentage}%)
          </Text>
        </View>

        {materials.map(material => (
          <View
            key={material.id}
            style={[
              styles.card,
              material.completed ? styles.cardCompleted : styles.cardActive,
            ]}
          >
            <View style={styles.cardHeader}>
              {getIcon(material.type)}
              <View style={styles.cardInfo}>
                <Text
                  style={[
                    styles.cardTitle,
                    material.completed && styles.cardTitleCompleted,
                  ]}
                >
                  {material.name}
                </Text>
                <Text style={styles.cardMeta}>
                  {material.size}
                  {material.duration && ` • ${material.duration}`}
                </Text>
              </View>
              {material.completed && (
                <Icon name="check-circle" size={20} color="#10b981" />
              )}
            </View>

            <View style={styles.actions}>
              <TouchableOpacity
                style={[
                  styles.button,
                  material.completed ? styles.buttonDisabled : styles.buttonPrimary,
                ]}
                onPress={() => {
                  handleView(material);
                  if (!material.completed) toggleComplete(material.id);
                }}
              >
                <Icon name="eye" size={14} color="#fff" />
                <Text style={styles.buttonText}>
                  {material.type === 'video' ? 'Watch' : 'View'}
                </Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.buttonOutline} onPress={() => handleDownload(material)}>
                <Icon name="download" size={14} color="#003366" />
                <Text style={styles.buttonOutlineText}>Download</Text>
              </TouchableOpacity>

              <TouchableOpacity style={styles.markButton} onPress={() => toggleComplete(material.id)}>
                <Text style={styles.markText}>{material.completed ? 'Mark Incomplete' : 'Mark Complete'}</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        {/* Completion Message */}
        {progressPercentage === 100 && (
          <View style={styles.completionCard}>
            <Icon name="check-circle" size={32} color="#10b981" />
            <Text style={styles.completionTitle}>Congratulations!</Text>
            <Text style={styles.completionText}>
              You've completed all course materials. Ready for your final assessment?
            </Text>
            <TouchableOpacity style={styles.finalButton} onPress={handleFinalAssessment}>
              <Text style={styles.finalButtonText}>Take Final Assessment</Text>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { backgroundColor: '#003366', padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  headerText: { flex: 1, marginLeft: 12 },
  headerTitle: { color: '#fff', fontSize: 18 },
  headerSubtitle: { color: '#ccc', fontSize: 13 },
  progressContainer: { padding: 16 },
  progressBar: { height: 6, backgroundColor: '#ccc', borderRadius: 3, overflow: 'hidden' },
  progressFill: { height: 6, backgroundColor: '#ff6600' },
  progressText: { color: '#666', fontSize: 12, marginTop: 8 },
  content: { padding: 16, paddingBottom: 48 },
  card: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 12 },
  cardCompleted: { opacity: 0.7 },
  cardActive: { elevation: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center' },
  cardInfo: { flex: 1, marginLeft: 10 },
  cardTitle: { fontSize: 14, color: '#003366' },
  cardTitleCompleted: { textDecorationLine: 'line-through', color: '#999' },
  cardMeta: { fontSize: 12, color: '#666', marginTop: 4 },
  actions: { flexDirection: 'row', marginTop: 10, alignItems: 'center' },
  button: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 6, marginRight: 8 },
  buttonPrimary: { backgroundColor: '#ff6600' },
  buttonDisabled: { backgroundColor: '#999' },
  buttonText: { color: '#fff', marginLeft: 6, fontSize: 12 },
  buttonOutline: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#003366', padding: 8, borderRadius: 6, marginRight: 8 },
  buttonOutlineText: { color: '#003366', marginLeft: 6, fontSize: 12 },
  markButton: { paddingVertical: 6, paddingHorizontal: 8 },
  markText: { color: '#003366', fontSize: 12 },
  completionCard: { backgroundColor: '#e6f4ea', padding: 20, borderRadius: 10, alignItems: 'center', marginTop: 20 },
  completionTitle: { fontSize: 18, color: '#10b981', marginTop: 10 },
  completionText: { fontSize: 14, color: '#555', textAlign: 'center', marginTop: 6 },
  finalButton: { backgroundColor: '#10b981', padding: 12, borderRadius: 6, marginTop: 12 },
  finalButtonText: { color: '#fff', fontSize: 14 },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
});
