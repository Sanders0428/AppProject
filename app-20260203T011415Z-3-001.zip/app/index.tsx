import React from 'react';
import AppProvider from './app'; // Adjust path if needed

export default function Index() {
  return <AppProvider />;
}