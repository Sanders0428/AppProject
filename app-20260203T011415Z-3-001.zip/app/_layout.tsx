import { View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';


import { Slot, usePathname } from 'expo-router';
import React from 'react';
import BottomNavigation from '../src/components/BottomNavigation';
import { AppProvider } from '../src/context/AppProvider';

export default function LearnerLayout() {
  const pathname = usePathname();
  const visiblePaths = ['/dashboard', '/courses', '/calendar', '/profile'];
  const showBottomNav = visiblePaths.includes(pathname);
   const insets = useSafeAreaInsets();

  return (
    <AppProvider>
      <Slot />
      {showBottomNav && (
  <View style={{ paddingBottom: insets.bottom }}>
    <BottomNavigation 
      userRole="learner" 
      activeTab={pathname!.slice(1) as any} 
    />
  </View>
)}
    </AppProvider>
  );
}
