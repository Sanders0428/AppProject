import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext } from 'react';
import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { AppContext } from '../src/context/AppContext';

export default function LearnerDashboard() {
  const router = useRouter();
  const context = useContext(AppContext);

  const handleMyCourses = () => {
    router.push('../courses');
  };

  const handleUpcomingAssessments = () => {
    router.push('/calendar');
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerTextContainer}>
          <Text style={styles.welcome}>Welcome back,</Text>
          <Text style={styles.name}>{context?.user?.fullName || 'Learner'}</Text>
        </View>
        <Icon name="bell" size={24} color="#fff" />
      </View>

      {/* Content */}
      <ScrollView contentContainerStyle={styles.content}>
        {/* Quick Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statCard}>
            <Icon name="book" size={24} color="#ff6600" />
            <Text style={styles.statLabel}>Enrolled</Text>
            <Text style={styles.statValue}>3</Text>
          </View>
          <View style={styles.statCard}>
            <Icon name="award" size={24} color="#ff6600" />
            <Text style={styles.statLabel}>Completed</Text>
            <Text style={styles.statValue}>5</Text>
          </View>
          <View style={styles.statCard}>
            <Icon name="users" size={24} color="#ff6600" />
            <Text style={styles.statLabel}>Certificates</Text>
            <Text style={styles.statValue}>2</Text>
          </View>
        </View>

      {/* Enroll Courses Button (Card Style) */}
<TouchableOpacity
  style={styles.enrollCard}
  onPress={() => router.push('../enroll-courses')}
>
  <View style={styles.enrollCardContent}>
    <Icon name="plus-circle" size={20} color="#ff6600" />
    <Text style={styles.enrollCardText}>Enroll in Courses</Text>
  </View>
</TouchableOpacity>

        {/* My Courses Card */}
        <TouchableOpacity style={styles.card} onPress={handleMyCourses}>
          <View style={styles.cardHeader}>
            <View style={styles.cardIcon}>
              <Icon name="book" size={20} color="#ff6600" />
            </View>
            <View style={styles.cardText}>
              <Text style={styles.cardTitle}>My Courses</Text>
              <Text style={styles.cardSubtitle}>Continue learning</Text>
            </View>
            <Icon name="chevron-right" size={20} color="#999" />
          </View>
          <View style={styles.progressRow}>
            <Text style={styles.progressLabel}>Soft Skills Development</Text>
            <Text style={styles.progressPercent}>75%</Text>
          </View>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '75%' }]} />
          </View>
        </TouchableOpacity>

        {/* Upcoming Assessments Card */}
        <TouchableOpacity style={styles.card} onPress={handleUpcomingAssessments}>
          <View style={styles.cardHeader}>
            <View style={styles.cardIcon}>
              <Icon name="calendar" size={20} color="#003366" />
            </View>
            <View style={styles.cardText}>
              <Text style={styles.cardTitle}>Upcoming Assessments</Text>
              <Text style={styles.cardSubtitle}>Stay on track</Text>
            </View>
            <Icon name="chevron-right" size={20} color="#999" />
          </View>
          <View style={styles.assessmentRow}>
            <View>
              <Text style={styles.assessmentTitle}>Project Submission</Text>
              <Text style={styles.assessmentSubtitle}>Career Guidance & Coaching</Text>
            </View>
            <Text style={styles.assessmentBadgeRed}>Due Tomorrow</Text>
          </View>
          <View style={styles.assessmentRow}>
            <View>
              <Text style={styles.assessmentTitle}>Quiz: Module 3</Text>
              <Text style={styles.assessmentSubtitle}>Life Coaching</Text>
            </View>
            <Text style={styles.assessmentBadgeYellow}>Due in 3 days</Text>
          </View>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { backgroundColor: '#003366', padding: 20, flexDirection: 'row', justifyContent: 'space-between' },
  headerTextContainer: {},
  welcome: { color: '#fff', fontSize: 16 },
  name: { color: '#ccc', fontSize: 14 },
  content: { padding: 20 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  statCard: { backgroundColor: '#fff', padding: 10, borderRadius: 10, alignItems: 'center', width: '30%' },
  statLabel: { fontSize: 12, color: '#666' },
  statValue: { fontSize: 18, color: '#003366' },
  card: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 20 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardIcon: { backgroundColor: '#ffe5cc', padding: 8, borderRadius: 8 },
  cardText: { flex: 1, marginLeft: 10 },
  cardTitle: { fontSize: 16, color: '#003366' },
  cardSubtitle: { fontSize: 12, color: '#666' },
  progressRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
  progressLabel: { fontSize: 12, color: '#666' },
  progressPercent: { fontSize: 12, color: '#ff6600' },
  progressBar: { height: 6, backgroundColor: '#ccc', borderRadius: 3, marginTop: 5 },
  progressFill: { height: 6, backgroundColor: '#ff6600', borderRadius: 3 },
  assessmentRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
  assessmentTitle: { fontSize: 14, color: '#003366' },
  assessmentSubtitle: { fontSize: 12, color: '#666' },
  assessmentBadgeRed: { backgroundColor: '#fdd', color: '#c00', padding: 4, borderRadius: 6, fontSize: 12 },
  assessmentBadgeYellow: { backgroundColor: '#fff3cd', color: '#856404', padding: 4, borderRadius: 6, fontSize: 12 },
enrollCard: {
  backgroundColor: '#fff',
  padding: 15,
  borderRadius: 10,
  marginBottom: 20, // space between button and card
  shadowColor: '#000',
  shadowOpacity: 0.03,
  shadowRadius: 8,
  elevation: 2,
},
enrollCardContent: {
  flexDirection: 'row',
  alignItems: 'center',
},
enrollCardText: {
  marginLeft: 10,
  fontSize: 16,
  fontWeight: '700',
  color: '#003366',
},

});
