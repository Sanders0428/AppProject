import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext } from 'react';
import {
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { AppContext } from '../src/context/AppContext';

const courses = [
  {
    id: '1',
    title: 'First Aid Training (Level 1–3)',
    description: 'Accredited first responder training for workplace emergencies.',
    mode: 'instructor-led',
    duration: '3 days',
  },
  {
    id: '2',
    title: 'Basic Fire Fighting',
    description: 'Learn to prevent and respond to workplace fire hazards.',
    mode: 'instructor-led',
    duration: '2 days',
  },
  {
    id: '3',
    title: 'SHE Rep (Safety, Health & Environment)',
    description: 'Become a certified workplace safety representative.',
    mode: 'instructor-led',
    duration: '5 days',
  },
  {
    id: '4',
    title: 'Forklift Operator',
    description: 'Accredited forklift operation and safety training.',
    mode: 'practical',
    duration: '5 days',
  },
  {
    id: '5',
    title: 'Working at Heights',
    description: 'Safe practices and rescue training for elevated work.',
    mode: 'instructor-led',
    duration: '3 days',
  },
];

const CoursesList = () => {
  const context = useContext(AppContext);
  const router = useRouter();

  const handleSelectCourse = (course: typeof courses[number]) => {
    context?.setSelectedCourse(course);
    router.push('/course-details');
  };

  const handleEnroll = (course: typeof courses[number]) => {
    if (context?.user) {
      const newEnrolledCourse = {
        id: course.id,
        title: course.title,
        description: course.description,
        mode: course.mode,
        duration: course.duration,
        image: '',
        enrolled: true,
        instructor: '',
      };
      const updatedUser = {
        ...context.user,
        enrolledCourses: [...(context.user.enrolledCourses || []), newEnrolledCourse],
      };
      context.setUser(updatedUser);
    }
    alert(`Enrolled in ${course.title}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Available Courses</Text>
        <Text style={styles.headerSubtitle}>Tap a course to view details or enroll</Text>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {courses.map(course => {
          const isEnrolled = context?.user?.enrolledCourses?.some(c => c.id === course.id);
          return (
            <View
              key={course.id}
              style={[styles.card, isEnrolled ? styles.cardEnrolled : styles.cardAvailable]}
            >
              <TouchableOpacity style={styles.cardRow} onPress={() => handleSelectCourse(course)}>
                <Icon name="book-open" size={20} color="#003366" />
                <Text style={styles.cardTitle}>{course.title}</Text>
                {isEnrolled && <Icon name="check-circle" size={16} color="#10b981" />}
              </TouchableOpacity>
              <Text style={styles.cardStatus}>
                {isEnrolled ? 'Enrolled' : 'Available'}
              </Text>
              {!isEnrolled && (
                <TouchableOpacity style={styles.enrollButton} onPress={() => handleEnroll(course)}>
                  <Text style={styles.enrollText}>Enroll</Text>
                </TouchableOpacity>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
};

export default CoursesList;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18 },
  headerSubtitle: { color: '#ccc', fontSize: 14, marginTop: 4 },
  content: { padding: 16 },
  card: { backgroundColor: '#fff', padding: 12, borderRadius: 8, marginBottom: 12 },
  cardRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  cardTitle: { fontSize: 14, color: '#003366', flex: 1, marginLeft: 10 },
  cardStatus: { fontSize: 12, color: '#666', marginTop: 6 },
  cardEnrolled: { borderLeftWidth: 4, borderLeftColor: '#10b981' },
  cardAvailable: { borderLeftWidth: 4, borderLeftColor: '#ff6600' },
  enrollButton: {
    marginTop: 8,
    backgroundColor: '#ff6600',
    paddingVertical: 6,
    borderRadius: 6,
    alignItems: 'center',
  },
  enrollText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
});
