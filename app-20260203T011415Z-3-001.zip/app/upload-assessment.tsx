import { Feather as Icon } from '@expo/vector-icons';
import React, { useContext, useState } from 'react';
import {
  Alert,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { AppContext } from '../src/context/AppContext';

import { useRouter } from 'expo-router';

const UploadAssessment = () => {
  const context = useContext(AppContext);
  const router = useRouter();
  const course = context?.selectedCourse;
  const [uploadedFiles, setUploadedFiles] = useState<{id:string,name:string,size:string,type:string}[]>([]);
  const [comments, setComments] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleBack = () => router.push('../app/course-details'); 

  const handleFileUpload = () => {
    const newFile = {
      id: Date.now().toString(),
      name: `Assignment_${Date.now()}.pdf`,
      size: '2.1 MB',
      type: 'pdf',
    };
    setUploadedFiles(prev => [...prev, newFile]);
  };

  const removeFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== fileId));
  };

  const handleSubmit = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      Alert.alert('Success', 'Assessment submitted successfully!');
      handleBack();
    }, 1500);
  };

  if (isSubmitting) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.headerTitle}>Submitting Assessment...</Text>
        </View>
        <View style={styles.centered}>
          <View style={styles.card}>
            <View style={styles.iconCircle}>
              <Icon name="check" size={32} color="#fff" />
            </View>
            <Text style={styles.cardTitle}>Submitting...</Text>
            <Text style={styles.cardText}>Please wait while we process your submission.</Text>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>
        <View>
          <Text style={styles.headerTitle}>Upload Assessment</Text>
          <Text style={styles.headerSubtitle}>{course?.title}</Text>
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Assessment Instructions</Text>
          <Text style={styles.instruction}>• Submit your completed project files in PDF, Word, or PowerPoint format</Text>
          <Text style={styles.instruction}>• Max file size: 10 MB per file</Text>
          <Text style={styles.instruction}>• Add comments below if needed</Text>
          <Text style={styles.instruction}>• Deadline: March 20, 2025 at 11:59 PM</Text>
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Upload Files</Text>
          <TouchableOpacity style={styles.uploadBox} onPress={handleFileUpload}>
            <Icon name="upload" size={28} color="#999" />
            <Text style={styles.uploadText}>Tap to upload files</Text>
            <Text style={styles.uploadHint}>or simulate drag & drop</Text>
          </TouchableOpacity>

          {uploadedFiles.length > 0 && (
            <View style={styles.fileList}>
              <Text style={styles.fileListTitle}>Uploaded Files:</Text>
              {uploadedFiles.map(file => (
                <View key={file.id} style={styles.fileItem}>
                  <View style={styles.fileInfo}>
                    <Icon name="file" size={16} color="#3b82f6" />
                    <View style={{ marginLeft: 8 }}>
                      <Text style={styles.fileName}>{file.name}</Text>
                      <Text style={styles.fileSize}>{file.size}</Text>
                    </View>
                  </View>
                  <TouchableOpacity onPress={() => removeFile(file.id)}>
                    <Icon name="x" size={16} color="#c00" />
                  </TouchableOpacity>
                </View>
              ))}
            </View>
          )}
        </View>

        <View style={styles.card}>
          <Text style={styles.sectionTitle}>Additional Comments (Optional)</Text>
          <TextInput
            style={styles.textarea}
            placeholder="Add any notes about your submission..."
            value={comments}
            onChangeText={setComments}
            multiline
            numberOfLines={4}
          />
        </View>

        <TouchableOpacity
          style={[styles.submitButton, uploadedFiles.length === 0 && styles.disabled]}
          onPress={handleSubmit}
          disabled={uploadedFiles.length === 0}
        >
          <Icon name="upload" size={16} color="#fff" />
          <Text style={styles.submitText}>Submit Assessment</Text>
        </TouchableOpacity>

        {uploadedFiles.length === 0 && (
          <Text style={styles.warning}>Please upload at least one file to submit</Text>
        )}
      </ScrollView>
    </View>
  );
};

export default UploadAssessment;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  header: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#003366', padding: 16 },
  headerTitle: { color: '#fff', fontSize: 18, marginLeft: 10 },
  headerSubtitle: { color: '#ccc', fontSize: 12, marginLeft: 10 },
  content: { padding: 16 },

  // merged card styles
  card: { 
    backgroundColor: '#fff', 
    padding: 16, 
    borderRadius: 8, 
    marginBottom: 16, 
    alignItems: 'center', // added for centered content where needed
    width: '100%',        // ensures it stretches in ScrollView
  },

  sectionTitle: { fontSize: 16, color: '#003366', marginBottom: 10 },
  instruction: { fontSize: 13, color: '#555', marginBottom: 4 },
  uploadBox: { borderWidth: 2, borderStyle: 'dashed', borderColor: '#ccc', padding: 20, alignItems: 'center', borderRadius: 8 },
  uploadText: { color: '#666', marginTop: 8 },
  uploadHint: { fontSize: 12, color: '#999' },

  fileList: { marginTop: 12 },
  fileListTitle: { fontSize: 14, color: '#003366', marginBottom: 6 },
  fileItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#f9f9f9', padding: 10, borderRadius: 6, marginBottom: 6 },
  fileInfo: { flexDirection: 'row', alignItems: 'center' },
  fileName: { fontSize: 14, color: '#003366' },
  fileSize: { fontSize: 12, color: '#666' },

  textarea: { borderWidth: 1, borderColor: '#ccc', borderRadius: 6, padding: 10, textAlignVertical: 'top', width: '100%' },
  submitButton: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', backgroundColor: '#ff6600', padding: 14, borderRadius: 6, marginTop: 10 },
  disabled: { backgroundColor: '#ccc' },
  submitText: { color: '#fff', marginLeft: 8, fontSize: 16 },
  warning: { fontSize: 12, color: '#999', textAlign: 'center', marginTop: 8 },

  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  iconCircle: { backgroundColor: '#ff6600', padding: 16, borderRadius: 50, marginBottom: 16 },
  cardTitle: { fontSize: 18, color: '#003366', marginBottom: 6 },
  cardText: { fontSize: 14, color: '#666', textAlign: 'center' },
});
