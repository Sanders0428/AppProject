// app/course-details.tsx
import { Feather as Icon } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useContext, useMemo } from 'react';
import { Alert, Image, ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { AppContext } from '../src/context/AppContext';

const CourseDetails = () => {
  const router = useRouter();
  const context = useContext(AppContext);

  const course = context?.selectedCourse;

  // defensive: if no context or no course, show fallback
  if (!context) {
    return (
      <View style={styles.centered}>
        <Text>App context not available</Text>
      </View>
    );
  }

  if (!course) {
    return (
      <View style={styles.centered}>
        <Text>Course not found</Text>
      </View>
    );
  }

  // Check if user already enrolled (reads from context.user.enrolledCourses)
  const isEnrolled = useMemo(() => {
    return !!context.user?.enrolledCourses?.some(c => c.id === course.id);
  }, [context.user, course.id]);

  const handleBack = () => {
    // prefer router back to maintain expo-router navigation
    router.back();
  };

  const handleJoinCourse = () => {
    if (!context.user) {
      Alert.alert('Not signed in', 'Please log in or register to join this course.');
      return;
    }

    if (!isEnrolled) {
      // enroll via context helper
      context.enrollCourse?.(course as any);
      Alert.alert('Enrolled', `You are now enrolled in "${course.title}"`);
      // after enrolling, navigate to materials or refresh details
      router.push('//course-materials');
      return;
    }

    // already enrolled -> continue learning
    router.push('//course-materials');
  };

  const handleUploadAssessment = () => {
    router.push('//upload-assessment');
  };

  // dummy lists for UI (you can derive these from course details later)
  const courseModules = [
    'Course Introduction and Objectives',
    'Fundamental Principles',
    'Safety Procedures and Protocols',
    'Practical Applications',
    'Assessment and Evaluation',
    'Certification and Next Steps',
  ];

  const learningOutcomes = [
    'Demonstrate competency in course objectives',
    'Apply safety principles in practice',
    'Meet professional standards',
    'Obtain recognized certification',
    'Continue professional development',
  ];

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack}>
          <Icon name="arrow-left" size={24} color="#fff" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Course Details</Text>
        <View style={{ width: 24 }} />
      </View>

      <ScrollView>
        {/* Banner */}
        <View style={styles.banner}>
          {course.image ? (
            <Image source={{ uri: course.image }} style={styles.bannerImage} />
          ) : (
            <View style={[styles.bannerImage, { justifyContent: 'center', alignItems: 'center', backgroundColor: '#eee' }]}>
              <Text style={{ color: '#666' }}>No image</Text>
            </View>
          )}

          <View style={styles.bannerOverlay}>
            <Text style={styles.modeBadge}>{(course.mode || 'SELF').toUpperCase()}</Text>
            {isEnrolled && <Text style={styles.enrolledBadge}>Enrolled</Text>}
          </View>
        </View>

        <View style={styles.content}>
          {/* Info */}
          <Text style={styles.title}>{course.title}</Text>
          <Text style={styles.description}>{course.description}</Text>

          <View style={styles.metaRow}>
            <View style={styles.metaItem}>
              <Icon name="users" size={16} color="#666" />
              <Text style={styles.metaText}>{course.instructor || 'Instructor'}</Text>
            </View>
            <View style={styles.metaItem}>
              <Icon name="clock" size={16} color="#666" />
              <Text style={styles.metaText}>{course.duration || 'Duration'}</Text>
            </View>
            <View style={styles.metaItem}>
              <Icon name="star" size={16} color="#f5a623" />
              <Text style={styles.metaText}>4.8 (124 reviews)</Text>
            </View>
          </View>

          {/* Modules */}
          <Text style={styles.sectionTitle}>Course Modules</Text>
          {courseModules.map((module, index) => (
            <View key={index} style={styles.moduleItem}>
              <Text style={styles.moduleIndex}>{index + 1}</Text>
              <Text style={styles.moduleText}>{module}</Text>
            </View>
          ))}

          {/* Outcomes */}
          <Text style={styles.sectionTitle}>What You'll Learn</Text>
          {learningOutcomes.map((outcome, index) => (
            <View key={index} style={styles.outcomeItem}>
              <View style={styles.outcomeDot} />
              <Text style={styles.outcomeText}>{outcome}</Text>
            </View>
          ))}

          {/* Actions */}
          <TouchableOpacity style={styles.button} onPress={handleJoinCourse}>
            <Icon name="play" size={16} color="#fff" />
            <Text style={styles.buttonText}>
              {isEnrolled ? 'Continue Learning' : 'Join Course'}
            </Text>
          </TouchableOpacity>

          {isEnrolled && (
            <TouchableOpacity style={styles.secondaryButton} onPress={handleUploadAssessment}>
              <Icon name="upload" size={16} color="#003366" />
              <Text style={styles.secondaryButtonText}>Upload Assessment</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </View>
  );
};

export default CourseDetails;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f2f2f2' },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  header: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#003366', padding: 16, justifyContent: 'space-between' },
  headerTitle: { color: '#fff', fontSize: 18 },
  banner: { position: 'relative' },
  bannerImage: { width: '100%', height: 180 },
  bannerOverlay: { position: 'absolute', top: 10, left: 10, right: 10, flexDirection: 'row', justifyContent: 'space-between' },
  modeBadge: { backgroundColor: '#e0f7fa', color: '#00796b', padding: 6, borderRadius: 6, fontSize: 12 },
  enrolledBadge: { backgroundColor: '#ff6600', color: '#fff', padding: 6, borderRadius: 6, fontSize: 12 },
  content: { padding: 16 },
  title: { fontSize: 22, color: '#003366', marginBottom: 8 },
  description: { fontSize: 14, color: '#666', marginBottom: 16 },
  metaRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 },
  metaItem: { flexDirection: 'row', alignItems: 'center' },
  metaText: { marginLeft: 6, fontSize: 12, color: '#666' },
  sectionTitle: { fontSize: 16, color: '#003366', marginTop: 20, marginBottom: 10 },
  moduleItem: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  moduleIndex: { backgroundColor: '#ffe5cc', color: '#ff6600', width: 24, height: 24, textAlign: 'center', borderRadius: 12, marginRight: 10 },
  moduleText: { fontSize: 14, color: '#333', flexShrink: 1 },
  outcomeItem: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 8 },
  outcomeDot: { width: 6, height: 6, backgroundColor: '#ff6600', borderRadius: 3, marginTop: 6, marginRight: 8 },
  outcomeText: { fontSize: 14, color: '#666', flex: 1 },
  button: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#ff6600', padding: 12, borderRadius: 6, marginTop: 20 },
  buttonText: { color: '#fff', fontSize: 16, marginLeft: 8 },
  secondaryButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: '#003366', padding: 12, borderRadius: 6, marginTop: 10 },
  secondaryButtonText: { color: '#003366', fontSize: 16, marginLeft: 8 },
});
