import { Feather as Icon } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import React, { useMemo } from 'react';
import {
    Alert,
    FlatList,
    Platform,
    Pressable,
    StyleSheet,
    Text,
    View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

type ModuleItem = {
  id: string;
  title: string;
  duration: string;
  completed?: boolean;
};

type Course = {
  id: string;
  title: string;
  subtitle?: string;
  description?: string;
  progress?: number;
  color?: string;
  modules: ModuleItem[];
};

const MOCK_COURSES: Course[] = [
  {
    id: 'c1',
    title: 'Soft Skills Development',
    subtitle: 'Communication & Teamwork',
    description:
      'Build communication, collaboration and workplace habits to boost employability and workplace confidence.',
    progress: 75,
    color: '#ff6600',
    modules: [
      { id: 'm1', title: 'Introduction & Goals', duration: '5m', completed: true },
      { id: 'm2', title: 'Active Listening', duration: '12m', completed: true },
      { id: 'm3', title: 'Giving Feedback', duration: '18m', completed: false },
      { id: 'm4', title: 'Teamwork Practices', duration: '22m', completed: false },
    ],
  },
  {
    id: 'c2',
    title: 'Career Guidance',
    subtitle: 'CV, Interviews & Networking',
    description:
      'Practical guidance for CVs, interviews and growing your professional network to get hired.',
    progress: 40,
    color: '#003366',
    modules: [
      { id: 'm1', title: 'Writing a CV', duration: '15m', completed: false },
      { id: 'm2', title: 'Interview Prep', duration: '25m', completed: false },
    ],
  },
];

export default function CourseDetail() {
  const router = useRouter();
  const params = useLocalSearchParams() as { id?: string };
  const courseId = params?.id ?? '';

  const course = useMemo(() => MOCK_COURSES.find((c) => c.id === courseId) ?? MOCK_COURSES[0], [courseId]);

  function onBack() {
    router.back();
  }

  function onOpenModule(module: ModuleItem) {
    // Navigate to a lesson route; adjust path to your structure
    // Example grouped path: router.push(`/(learner)/courses/${course.id}/modules/${module.id}`)
    router.push(`/course-details?courseId=${course.id}&moduleId=${module.id}`);
  }

  function onContinue() {
    // Find first incomplete module or open the last incomplete one
    const next = course.modules.find((m) => !m.completed) ?? course.modules[course.modules.length - 1];
    if (next) {
      onOpenModule(next);
    } else {
      Alert.alert('Completed', 'You have finished this course.');
    }
  }

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <View style={styles.container}>
        <View style={styles.header}>
          <Pressable onPress={onBack} style={styles.backButton} accessibilityRole="button">
            <Icon name="chevron-left" size={22} color="#003366" />
          </Pressable>
          <View style={styles.headerText}>
            <Text style={styles.title}>{course.title}</Text>
            {course.subtitle ? <Text style={styles.subtitle}>{course.subtitle}</Text> : null}
          </View>
        </View>

        <View style={styles.meta}>
          <View style={[styles.colorChip, { backgroundColor: course.color || '#ccc' }]} />
          <View style={styles.metaText}>
            <Text style={styles.progressLabel}>Progress</Text>
            <Text style={styles.progressValue}>{course.progress ?? 0}%</Text>
          </View>
          <Pressable
            style={({ pressed }) => [styles.continueButton, pressed && styles.pressed]}
            onPress={onContinue}
            accessibilityRole="button"
          >
            <Text style={styles.continueText}>{course.progress && course.progress < 100 ? 'Continue' : 'Review'}</Text>
          </Pressable>
        </View>

        <View style={styles.descriptionWrap}>
          <Text style={styles.description}>{course.description}</Text>
        </View>

        <Text style={styles.sectionTitle}>Modules</Text>

        <FlatList
          data={course.modules}
          keyExtractor={(i) => i.id}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => onOpenModule(item)}
              style={({ pressed }) => [styles.moduleRow, pressed && styles.modulePressed]}
              accessibilityRole="button"
            >
              <View style={styles.moduleLeft}>
                <View style={[styles.moduleBullet, item.completed && styles.moduleBulletDone]} />
              </View>
              <View style={styles.moduleBody}>
                <Text style={styles.moduleTitle}>{item.title}</Text>
                <Text style={styles.moduleMeta}>{item.duration}</Text>
              </View>
              <View style={styles.moduleRight}>
                {item.completed ? <Icon name="check" size={16} color="#2a9d8f" /> : <Icon name="play" size={16} color="#003366" />}
              </View>
            </Pressable>
          )}
          ItemSeparatorComponent={() => <View style={styles.sep} />}
          contentContainerStyle={{ paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#f2f2f2' },
  container: { flex: 1, paddingHorizontal: 16 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: Platform.OS === 'android' ? 4 : 8,
    marginBottom: 12,
  },
  backButton: { padding: 8, marginRight: 8 },
  headerText: { flex: 1 },
  title: { fontSize: 20, color: '#003366', fontWeight: '700' },
  subtitle: { fontSize: 12, color: '#666', marginTop: 2 },
  meta: { flexDirection: 'row', alignItems: 'center', marginBottom: 12 },
  colorChip: { width: 10, height: 40, borderRadius: 6, marginRight: 10 },
  metaText: { flex: 1 },
  progressLabel: { fontSize: 12, color: '#666' },
  progressValue: { fontSize: 14, color: '#003366', fontWeight: '700' },
  continueButton: { backgroundColor: '#003366', paddingHorizontal: 14, paddingVertical: 10, borderRadius: 8 },
  continueText: { color: '#fff', fontWeight: '600' },
  pressed: { opacity: 0.85 },
  descriptionWrap: { backgroundColor: '#fff', padding: 12, borderRadius: 10, marginBottom: 12 },
  description: { color: '#444', fontSize: 13 },
  sectionTitle: { fontSize: 16, color: '#003366', fontWeight: '700', marginBottom: 8 },
  moduleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 10,
  },
  modulePressed: { opacity: 0.85 },
  moduleLeft: { width: 28, alignItems: 'center' },
  moduleBullet: { width: 10, height: 10, borderRadius: 6, backgroundColor: '#ddd' },
  moduleBulletDone: { backgroundColor: '#2a9d8f' },
  moduleBody: { flex: 1, marginLeft: 8 },
  moduleTitle: { color: '#003366', fontSize: 14, fontWeight: '600' },
  moduleMeta: { color: '#666', fontSize: 12, marginTop: 4 },
  moduleRight: { width: 32, alignItems: 'center' },
  sep: { height: 10 },
});