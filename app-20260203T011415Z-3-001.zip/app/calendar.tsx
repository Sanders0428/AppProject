import { Feather as Icon } from '@expo/vector-icons';
import React, { useContext, useState } from 'react';
import {
    Modal,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    TouchableWithoutFeedback,
    View,
} from 'react-native';
import { AppContext } from '../src/context/AppContext';

interface CalendarEvent {
    id: string;
    title: string;
    date: Date;
    type: 'assignment' | 'exam' | 'class' | 'deadline';
    course: string;
}

const mockEvents: CalendarEvent[] = [
    { id: '1', title: 'Project Submission', date: new Date(2025, 2, 15), type: 'deadline', course: 'Digital Marketing' },
    { id: '2', title: 'Module 3 Quiz', date: new Date(2025, 2, 18), type: 'exam', course: 'Business Communication' },
    { id: '3', title: 'Live Workshop', date: new Date(2025, 2, 20), type: 'class', course: 'Project Management' },
    { id: '4', title: 'Essay Due', date: new Date(2025, 2, 22), type: 'assignment', course: 'Financial Literacy' },
];

const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const dayNames = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];

const CalendarScreen: React.FC = () => {
    const context = useContext(AppContext);
    const [currentDate, setCurrentDate] = useState(new Date(2025, 2, 1));
    const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);

    const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay();

    const navigateMonth = (direction: 'prev' | 'next') => {
        setCurrentDate(prev => {
            const newDate = new Date(prev);
            newDate.setMonth(direction === 'prev' ? newDate.getMonth() - 1 : newDate.getMonth() + 1);
            return newDate;
        });
    };

    const getEventsForDate = (date: number) =>
        mockEvents.filter(event =>
            event.date.getDate() === date &&
            event.date.getMonth() === currentDate.getMonth() &&
            event.date.getFullYear() === currentDate.getFullYear()
        );

    const getEventColor = (type: CalendarEvent['type']): string => {
        switch (type) {
            case 'assignment': return '#3b82f6';
            case 'exam': return '#ef4444';
            case 'class': return '#10b981';
            case 'deadline': return '#f97316';
            default: return '#999';
        }
    };

    const getEventTypeLabel = (type: CalendarEvent['type']): string => {
        switch (type) {
            case 'assignment': return 'Assignment';
            case 'exam': return 'Exam';
            case 'class': return 'Class';
            case 'deadline': return 'Deadline';
            default: return 'Event';
        }
    };

    const isAdmin = context?.user?.role === 'admin';
    const today = new Date();

    return (
        <View style={styles.container}>
            {/* Header */}
            <View style={styles.header}>
                <Text style={styles.headerTitle}>Calendar</Text>
                {isAdmin && (
                    <TouchableOpacity style={styles.addButton}>
                        <Icon name="plus" size={16} color="#fff" />
                        <Text style={styles.addButtonText}>Add Event</Text>
                    </TouchableOpacity>
                )}
            </View>

            {/* Calendar */}
            <ScrollView style={styles.content}>
                <View style={styles.calendarHeader}>
                    <TouchableOpacity onPress={() => navigateMonth('prev')}>
                        <Icon name="chevron-left" size={20} color="#003366" />
                    </TouchableOpacity>
                    <Text style={styles.monthLabel}>
                        {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
                    </Text>
                    <TouchableOpacity onPress={() => navigateMonth('next')}>
                        <Icon name="chevron-right" size={20} color="#003366" />
                    </TouchableOpacity>
                </View>

                {/* Day Names */}
                <View style={styles.dayRow}>
                    {dayNames.map(day => (
                        <Text key={day} style={styles.dayName}>{day}</Text>
                    ))}
                </View>

                {/* Calendar Grid */}
                <View style={styles.grid}>
                    {Array.from({ length: firstDayOfMonth }, (_, i) => (
                        <View key={`empty-${i}`} style={styles.cell} />
                    ))}
                    {Array.from({ length: daysInMonth }, (_, i) => {
                        const date = i + 1;
                        const events = getEventsForDate(date);
                        const isToday =
                            today.getDate() === date &&
                            today.getMonth() === currentDate.getMonth() &&
                            today.getFullYear() === currentDate.getFullYear();

                        return (
                            <TouchableOpacity
                                key={date}
                                style={[styles.cell, isToday && styles.today]}
                                onPress={() => events[0] && setSelectedEvent(events[0])}
                                activeOpacity={0.8}
                            >
                                <Text style={[styles.dateText, isToday && styles.todayText]}>{date}</Text>
                                <View style={styles.dotsRow}>
                                    {events.slice(0, 2).map(event => (
                                        <View
                                            key={event.id}
                                            style={[styles.dot, { backgroundColor: getEventColor(event.type) }]}
                                        />
                                    ))}
                                    {events.length > 2 && <View style={[styles.dot, { backgroundColor: '#999' }]} />}
                                </View>
                            </TouchableOpacity>
                        );
                    })}
                </View>

                {/* Upcoming Events */}
                <Text style={styles.sectionTitle}>Upcoming Events</Text>
                {mockEvents
                    .filter(event => event.date >= today)
                    .sort((a, b) => a.date.getTime() - b.date.getTime())
                    .slice(0, 5)
                    .map(event => (
                        <TouchableOpacity
                            key={event.id}
                            style={styles.eventItem}
                            onPress={() => setSelectedEvent(event)}
                        >
                            <View style={[styles.eventDot, { backgroundColor: getEventColor(event.type) }]} />
                            <View style={styles.eventDetails}>
                                <Text style={styles.eventTitle}>{event.title}</Text>
                                <Text style={styles.eventMeta}>
                                    {event.course} • {event.date.toLocaleDateString()}
                                </Text>
                            </View>
                            <Text style={styles.eventType}>{getEventTypeLabel(event.type)}</Text>
                        </TouchableOpacity>
                    ))}
            </ScrollView>

            {/* Event Modal */}
            <Modal visible={!!selectedEvent} transparent animationType="fade">
                <TouchableWithoutFeedback onPress={() => setSelectedEvent(null)}>
                    <View style={styles.modalOverlay}>
                        <TouchableWithoutFeedback>
                            <View style={styles.modalCard}>
                                <View style={styles.modalHeader}>
                                    <View style={[styles.eventDot, { backgroundColor: selectedEvent ? getEventColor(selectedEvent.type) : '#999' }]} />
                                    <Text style={styles.modalTitle}>{selectedEvent?.title}</Text>
                                </View>
                                <Text style={styles.modalText}>Course: {selectedEvent?.course}</Text>
                                <Text style={styles.modalText}>Date: {selectedEvent?.date.toLocaleDateString()}</Text>
                                <Text style={styles.modalText}>Type: {selectedEvent ? getEventTypeLabel(selectedEvent.type) : ''}</Text>
                                <View style={styles.modalActions}>
                                    <TouchableOpacity style={styles.modalButton}>
                                        <Text style={styles.modalButtonText}>View Details</Text>
                                    </TouchableOpacity>
                                    <TouchableOpacity style={styles.modalButtonOutline} onPress={() => setSelectedEvent(null)}>
                                        <Text style={[styles.modalButtonText, { color: '#003366' }]}>Close</Text>
                                    </TouchableOpacity>
                                </View>
                            </View>
                        </TouchableWithoutFeedback>
                    </View>
                </TouchableWithoutFeedback>
            </Modal>
        </View>
    );
};

export default CalendarScreen;


const styles = StyleSheet.create({
    container: { flex: 1, backgroundColor: '#f2f2f2' },
    header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#003366', padding: 16 },
    headerTitle: { color: '#fff', fontSize: 18, fontWeight: '600' },
    addButton: { flexDirection: 'row', backgroundColor: '#ff6600', paddingVertical: 8, paddingHorizontal: 10, borderRadius: 6, alignItems: 'center' },
    addButtonText: { color: '#fff', marginLeft: 6, fontWeight: '600' },
    content: { padding: 16 },
    calendarHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
    monthLabel: { fontSize: 16, color: '#003366', fontWeight: '600' },
    dayRow: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 6, marginBottom: 6 },
    dayName: { width: `${100 / 7}%`, textAlign: 'center', color: '#666', fontSize: 12 },
    grid: { flexDirection: 'row', flexWrap: 'wrap' },
    cell: { width: `${100 / 7}%`, aspectRatio: 1, padding: 6, alignItems: 'center', justifyContent: 'flex-start', borderWidth: 0.5, borderColor: '#eee' },
    dateText: { color: '#333', fontSize: 14 },
    dotsRow: { flexDirection: 'row', marginTop: 6 },
    dot: { width: 8, height: 8, borderRadius: 4, marginRight: 4 },
    today: { backgroundColor: '#e6f2ff' },
    todayText: { color: '#003366', fontWeight: '700' },
    sectionTitle: { marginTop: 16, marginBottom: 8, fontSize: 16, fontWeight: '600', color: '#003366' },
    eventItem: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', padding: 10, marginBottom: 8, borderRadius: 8, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
    eventDot: { width: 12, height: 12, borderRadius: 6, marginRight: 10 },
    eventDetails: { flex: 1 },
    eventTitle: { fontSize: 14, fontWeight: '600', color: '#111' },
    eventMeta: { color: '#666', fontSize: 12 },
    eventType: { color: '#666', fontSize: 12, marginLeft: 8 },
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.4)', justifyContent: 'center', alignItems: 'center', padding: 20 },
    modalCard: { width: '100%', maxWidth: 420, backgroundColor: '#fff', borderRadius: 8, padding: 16 },
    modalHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
    modalTitle: { fontSize: 16, fontWeight: '700', marginLeft: 8, color: '#111' },
    modalText: { color: '#444', marginBottom: 6 },
    modalActions: { flexDirection: 'row', justifyContent: 'flex-end', marginTop: 12 },
    modalButton: { backgroundColor: '#003366', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, marginLeft: 8 },
    modalButtonOutline: { borderWidth: 1, borderColor: '#003366', paddingVertical: 8, paddingHorizontal: 12, borderRadius: 6, marginLeft: 8 },
    modalButtonText: { color: '#fff', fontWeight: '600' },
});